import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Padding, Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const Login = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.login}>
      <View style={styles.background} />
      <Image
        style={styles.objectsIcon}
        contentFit="cover"
        source={require("../assets/objects.png")}
      />
      <View style={styles.header}>
        <Text style={styles.loginHere}>Login here</Text>
        <Text style={styles.welcomeBackYouve}>{`Welcome back you’ve
been missed!`}</Text>
        <Image
          style={styles.subject1Icon}
          contentFit="cover"
          source={require("../assets/subject-1.png")}
        />
      </View>
      <View style={styles.formPosition}>
        <View>
          <View style={[styles.input, styles.inputSpaceBlock1]}>
            <Text style={styles.placeholder}>Email</Text>
          </View>
          <View style={[styles.input1, styles.inputSpaceBlock1]}>
            <Text style={styles.placeholder}>Password</Text>
          </View>
        </View>
        <Text style={[styles.forgotYourPassword, styles.forgotTypo]}>
          Forgot your password?
        </Text>
        <View style={styles.actions}>
          <View style={[styles.buttonactive, styles.buttonactiveShadowBox]}>
            <Text style={styles.buttonTypo}>Sign in</Text>
          </View>
          <View style={styles.buttonsmall}>
            <Text style={[styles.button1, styles.forgotTypo]}>
              Create new account
            </Text>
          </View>
        </View>
      </View>
      <View style={[styles.form1, styles.formPosition]}>
        <View>
          <View style={[styles.input2, styles.inputSpaceBlock]}>
            <Text style={styles.placeholder}>Email</Text>
          </View>
          <View style={[styles.input3, styles.inputSpaceBlock]}>
            <Text style={styles.placeholder}>Password</Text>
          </View>
        </View>
        <Text style={[styles.forgotYourPassword1, styles.forgotTypo]}>
          Forgot your password?
        </Text>
        <View style={[styles.buttonactive11, styles.buttonactiveShadowBox]}>
          <Pressable onPress={() => navigation.navigate("Homescreen1")}>
            <Text style={styles.buttonTypo}>Sign in</Text>
          </Pressable>
        </View>
        <View style={styles.buttonsmall}>
          <Text style={[styles.button1, styles.forgotTypo]}>
            Create new account
          </Text>
        </View>
      </View>
      <View style={styles.socialMedia}>
        <Text style={[styles.orContinueWith, styles.forgotTypo]}>
          Or continue with
        </Text>
        <View style={styles.socialMedia1}>
          <View style={styles.googleFlexBox}>
            <Image
              style={styles.googleChild}
              contentFit="cover"
              source={require("../assets/frame-1.png")}
            />
          </View>
          <View style={[styles.facebook, styles.googleFlexBox]}>
            <Image
              style={styles.googleChild}
              contentFit="cover"
              source={require("../assets/frame-11.png")}
            />
          </View>
          <View style={[styles.facebook, styles.googleFlexBox]}>
            <Image
              style={styles.googleChild}
              contentFit="cover"
              source={require("../assets/frame-12.png")}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  inputSpaceBlock1: {
    paddingBottom: Padding.p_xl,
    paddingRight: Padding.p_16xl,
    paddingTop: Padding.p_xl,
    paddingLeft: Padding.p_xl,
    width: 357,
    backgroundColor: Color.colorGhostwhite_100,
    borderRadius: Border.br_3xs,
    alignItems: "center",
    flexDirection: "row",
  },
  forgotTypo: {
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.calloutBold,
    fontWeight: "600",
    textAlign: "center",
  },
  buttonactiveShadowBox: {
    paddingVertical: Padding.p_mini,
    paddingHorizontal: Padding.p_xl,
    justifyContent: "center",
    shadowOpacity: 1,
    elevation: 20,
    shadowRadius: 20,
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowColor: "#cbd6ff",
    alignItems: "center",
    flexDirection: "row",
    width: 357,
    borderRadius: Border.br_3xs,
  },
  formPosition: {
    alignItems: "flex-end",
    left: 10,
    top: 337,
    position: "absolute",
  },
  inputSpaceBlock: {
    backgroundColor: Color.colorGainsboro_200,
    paddingBottom: Padding.p_xl,
    paddingRight: Padding.p_16xl,
    paddingTop: Padding.p_xl,
    paddingLeft: Padding.p_xl,
    alignItems: "center",
    flexDirection: "row",
    width: 357,
    borderRadius: Border.br_3xs,
  },
  googleFlexBox: {
    width: 60,
    backgroundColor: Color.colorWhitesmoke_300,
    paddingVertical: Padding.p_3xs,
    paddingHorizontal: Padding.p_xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    borderRadius: Border.br_3xs,
  },
  background: {
    top: -26,
    left: -28,
    width: 428,
    height: 926,
    position: "absolute",
  },
  objectsIcon: {
    top: -382,
    left: -392,
    width: 1113,
    height: 1431,
    position: "absolute",
  },
  loginHere: {
    top: 172,
    left: 33,
    fontSize: FontSize.size_11xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    textAlign: "center",
    color: Color.colorBlack,
    position: "absolute",
  },
  welcomeBackYouve: {
    top: 217,
    left: 1,
    fontFamily: FontFamily.calloutBold,
    fontWeight: "600",
    fontSize: FontSize.size_xl,
    textAlign: "center",
    color: Color.colorBlack,
    position: "absolute",
  },
  subject1Icon: {
    height: "55.96%",
    width: "81.33%",
    top: "0%",
    right: "10.36%",
    bottom: "44.04%",
    left: "8.31%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  header: {
    top: 51,
    left: 74,
    width: 225,
    height: 277,
    position: "absolute",
  },
  placeholder: {
    fontSize: FontSize.calloutBold_size,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorDimgray_100,
    textAlign: "center",
  },
  input: {
    borderColor: Color.colorBlack,
    borderWidth: 2,
    borderStyle: "solid",
  },
  input1: {
    marginTop: 29,
  },
  forgotYourPassword: {
    marginTop: 30,
    color: Color.colorBlack,
  },
  buttonTypo: {
    color: Color.labelPrimary,
    fontFamily: FontFamily.calloutBold,
    fontWeight: "600",
    fontSize: FontSize.size_xl,
    textAlign: "center",
  },
  buttonactive: {
    backgroundColor: Color.colorBlack,
  },
  button1: {
    color: Color.colorDarkslategray_100,
  },
  buttonsmall: {
    paddingVertical: Padding.p_3xs,
    paddingHorizontal: Padding.p_xl,
    justifyContent: "center",
    marginTop: 30,
    alignItems: "center",
    flexDirection: "row",
    width: 357,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.labelPrimary,
  },
  actions: {
    marginTop: 30,
  },
  input2: {
    borderColor: Color.colorSienna_100,
    borderWidth: 2,
    borderStyle: "solid",
  },
  input3: {
    marginTop: 29,
  },
  forgotYourPassword1: {
    color: Color.colorSienna_100,
    marginTop: 30,
  },
  buttonactive11: {
    backgroundColor: Color.colorSienna_100,
    marginTop: 30,
  },
  form1: {
    backgroundColor: Color.labelPrimary,
  },
  orContinueWith: {
    color: Color.colorGray_200,
  },
  googleChild: {
    width: 24,
    height: 24,
  },
  facebook: {
    marginLeft: 10,
  },
  socialMedia1: {
    justifyContent: "flex-end",
    marginTop: 20,
    flexDirection: "row",
  },
  socialMedia: {
    top: 714,
    left: 89,
    alignItems: "center",
    position: "absolute",
  },
  login: {
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    backgroundColor: Color.labelPrimary,
  },
});

export default Login;
