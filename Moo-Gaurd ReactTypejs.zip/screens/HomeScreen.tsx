import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Padding, Border } from "../GlobalStyles";

const HomeScreen = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.homeScreen}>
      <View style={styles.frame}>
        <Image
          style={styles.frameIcon}
          contentFit="cover"
          source={require("../assets/frame.png")}
        />
        <Image
          style={styles.frameIcon1}
          contentFit="cover"
          source={require("../assets/frame1.png")}
        />
      </View>
      <View style={styles.frame1}>
        <View style={styles.texts}>
          <Text style={styles.guardingYourHerd}>
            Guarding Your Herd, One Moo at a Time!
          </Text>
          <Text style={styles.protectingYourLivestock}>
            Protecting your livestock !
          </Text>
        </View>
        <View style={styles.actionButtons}>
          <Pressable
            style={styles.buttonactive}
            onPress={() => navigation.navigate("Login")}
          >
            <Text style={styles.button}>Login</Text>
          </Pressable>
          <View style={styles.buttondefault}>
            <Text style={styles.button1}>Register</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameIcon: {
    position: "relative",
    width: 191,
    height: 155,
    overflow: "hidden",
  },
  frameIcon1: {
    position: "relative",
    width: 351,
    height: 165,
    overflow: "hidden",
    marginTop: 54,
  },
  frame: {
    width: 351,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  guardingYourHerd: {
    fontSize: 32,
    fontWeight: "600",
    fontFamily: FontFamily.calloutBold,
    color: Color.colorBlack,
    textAlign: "center",
    width: 343,
    height: 96,
    marginLeft: 11,
  },
  protectingYourLivestock: {
    position: "relative",
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.caption2,
    color: Color.colorBlack,
    textAlign: "center",
    width: 323,
    marginTop: 13,
  },
  texts: {
    width: 351,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
    paddingHorizontal: Padding.p_5xs,
    paddingVertical: 0,
    height: 130,
    marginRight: 2,
  },
  button: {
    position: "relative",
    fontSize: FontSize.size_xl,
    fontWeight: "600",
    fontFamily: FontFamily.calloutBold,
    color: Color.colorWhitesmoke_200,
    textAlign: "center",
  },
  buttonactive: {
    shadowColor: "#cbd6ff",
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorSienna_100,
    width: 160,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_xl,
    paddingVertical: Padding.p_mini,
  },
  button1: {
    position: "relative",
    fontSize: FontSize.size_xl,
    fontWeight: "600",
    fontFamily: FontFamily.calloutBold,
    color: Color.colorGray_300,
    textAlign: "center",
  },
  buttondefault: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorWhitesmoke_200,
    width: 160,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_xl,
    paddingVertical: Padding.p_mini,
    marginLeft: 30,
  },
  actionButtons: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
    height: 60,
    marginLeft: 1,
    marginTop: 54,
  },
  frame1: {
    width: 353,
    height: 244,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginTop: 38,
  },
  homeScreen: {
    position: "relative",
    backgroundColor: Color.labelPrimary,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-end",
    paddingHorizontal: 11,
    paddingTop: 101,
    paddingBottom: 55,
  },
});

export default HomeScreen;
