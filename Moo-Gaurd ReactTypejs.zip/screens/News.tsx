import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const News = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.news}>
      <View style={styles.frame}>
        <View style={styles.frame1} />
        <View style={styles.frameParent}>
          <View style={styles.frame2}>
            <Image
              style={styles.frameIcon}
              contentFit="cover"
              source={require("../assets/frame11.png")}
            />
            <Image
              style={styles.frameIcon1}
              contentFit="cover"
              source={require("../assets/frame12.png")}
            />
          </View>
          <View style={styles.frame3}>
            <View style={styles.frame4}>
              <Text style={styles.mooGuard}>Moo-Guard</Text>
            </View>
            <View style={styles.frame5}>
              <Image
                style={styles.fluentpersonFeedback24ReguIcon}
                contentFit="cover"
                source={require("../assets/fluentpersonfeedback24regular1.png")}
              />
              <Image
                style={styles.tablernotificationIcon}
                contentFit="cover"
                source={require("../assets/tablernotification1.png")}
              />
            </View>
          </View>
        </View>
      </View>
      <View style={styles.frame6}>
        <View style={styles.frame7}>
          <Image
            style={styles.frameIcon2}
            contentFit="cover"
            source={require("../assets/frame13.png")}
          />
          <View style={styles.frame8}>
            <View style={styles.frame9}>
              <Text
                style={styles.over200Stolen}
              >{`Over 200 stolen animals recovered in
cross-border operation`}</Text>
              <Text
                style={styles.policeInspectorGeneral}
              >{`Police inspector general Joseph Shikongo said the police recorded 23 791 stolen livestock between May 2021 and April 2023.
Shikongo said this during a stakeholder engagement meeting with the police, the Namibia Agricultural Union and the Emerging Commercial Farmers’ Union in Windhoek yesterday.`}</Text>
              <View style={styles.footer}>
                <View style={styles.footerChild} />
                <Image
                  style={styles.profileIcon}
                  contentFit="cover"
                  source={require("../assets/profile.png")}
                />
                <Text style={styles.janeCooper}>Jane Cooper</Text>
                <View style={styles.view}>
                  <Text style={styles.text}>76</Text>
                  <Image
                    style={styles.faRegulareyeIcon}
                    contentFit="cover"
                    source={require("../assets/faregulareye1.png")}
                  />
                </View>
                <View style={styles.date}>
                  <Text style={styles.sept2022}>17 Sept 2022</Text>
                  <Image
                    style={styles.dateChild}
                    contentFit="cover"
                    source={require("../assets/ellipse-7.png")}
                  />
                </View>
                <View style={styles.like}>
                  <Text style={styles.like1}>Like</Text>
                  <Image
                    style={styles.antDesignlikeFilledIcon}
                    contentFit="cover"
                    source={require("../assets/antdesignlikefilled.png")}
                  />
                </View>
                <View style={styles.share}>
                  <Text style={styles.share1}>Share</Text>
                  <Image
                    style={styles.iconParkSolidshareTwo}
                    contentFit="cover"
                    source={require("../assets/iconparksolidsharetwo.png")}
                  />
                </View>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.container}>
          <View style={styles.container1}>
            <Pressable
              style={styles.home}
              onPress={() => navigation.navigate("Homescreen1")}
            >
              <Image
                style={styles.homeIcon}
                contentFit="cover"
                source={require("../assets/home1.png")}
              />
              <Text style={styles.home1}>Home</Text>
            </Pressable>
            <Pressable
              style={styles.saved}
              onPress={() => navigation.navigate("Geofencing")}
            >
              <Image
                style={styles.googleMapsIcon}
                contentFit="cover"
                source={require("../assets/google-maps1.png")}
              />
              <Text style={styles.home1}>Tracking</Text>
            </Pressable>
            <View style={styles.saved1}>
              <Image
                style={styles.heartIcon}
                contentFit="cover"
                source={require("../assets/heart1.png")}
              />
              <Text style={styles.home1}>Saved</Text>
            </View>
            <Pressable
              style={styles.cart}
              onPress={() => navigation.navigate("Camera")}
            >
              <Image
                style={styles.cameraIcon}
                contentFit="cover"
                source={require("../assets/camera1.png")}
              />
              <Text style={styles.home1}>Surveillance</Text>
            </Pressable>
            <Pressable
              style={styles.cart}
              onPress={() => navigation.navigate("Settings")}
            >
              <Image
                style={styles.heartIcon}
                contentFit="cover"
                source={require("../assets/user1.png")}
              />
              <Text style={styles.account}>Account</Text>
            </Pressable>
          </View>
          <View style={styles.homeindicator}>
            <View style={styles.homeIndicator} />
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frame1: {
    width: 455,
    height: 47,
    overflow: "hidden",
    justifyContent: "center",
    alignItems: "flex-start",
  },
  frameIcon: {
    position: "relative",
    width: 30,
    height: 37,
    overflow: "hidden",
  },
  frameIcon1: {
    position: "relative",
    width: 45,
    height: 40,
    overflow: "hidden",
    marginLeft: 5,
  },
  frame2: {
    width: 80,
    height: 40,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  mooGuard: {
    position: "relative",
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorSienna_100,
    textAlign: "left",
    width: 147,
    height: 29,
  },
  frame4: {
    width: 147,
    height: 35,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  fluentpersonFeedback24ReguIcon: {
    position: "relative",
    width: 33,
    height: 33,
    overflow: "hidden",
  },
  tablernotificationIcon: {
    position: "relative",
    width: 31,
    height: 31,
    overflow: "hidden",
    marginLeft: 10,
  },
  frame5: {
    width: 74,
    height: 33,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    marginLeft: 49,
  },
  frame3: {
    width: 271,
    height: 35,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    marginLeft: 7,
  },
  frameParent: {
    width: 358,
    height: 40,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    marginRight: 9,
    marginTop: 6,
  },
  frame: {
    position: "absolute",
    top: 0,
    left: -40,
    width: 455,
    height: 93,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  frameIcon2: {
    position: "relative",
    width: 367,
    height: 294,
    overflow: "hidden",
  },
  over200Stolen: {
    position: "absolute",
    top: 0,
    left: 6,
    fontSize: FontSize.size_xl,
    fontWeight: "600",
    fontFamily: FontFamily.openSansSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
  },
  policeInspectorGeneral: {
    position: "absolute",
    top: 54,
    left: 10,
    fontSize: FontSize.size_mini,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorBlack,
    textAlign: "left",
    width: 325,
    height: 224,
  },
  footerChild: {
    position: "absolute",
    top: 0,
    left: 0,
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderTopWidth: 1,
    width: 362,
    height: 1,
  },
  profileIcon: {
    position: "absolute",
    top: 9,
    left: 0,
    width: 48,
    height: 48,
  },
  janeCooper: {
    position: "absolute",
    top: 17,
    left: 57,
    fontSize: FontSize.size_sm,
    fontWeight: "700",
    fontFamily: FontFamily.comfortaaBold,
    color: "#5a5a5a",
    textAlign: "center",
  },
  text: {
    position: "absolute",
    height: "100%",
    width: "41.94%",
    top: "0%",
    left: "241.94%",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  faRegulareyeIcon: {
    position: "absolute",
    top: 1,
    left: 0,
    width: 15,
    height: 12,
    overflow: "hidden",
  },
  view: {
    position: "absolute",
    top: 36,
    left: 57,
    width: 31,
    height: 16,
  },
  sept2022: {
    position: "absolute",
    top: "0%",
    left: "171.83%",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  dateChild: {
    position: "absolute",
    top: 3,
    left: 0,
    width: 8,
    height: 8,
  },
  date: {
    position: "absolute",
    top: 36,
    left: 112,
    width: 71,
    height: 14,
  },
  like1: {
    position: "absolute",
    top: "65.85%",
    left: "953.33%",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  antDesignlikeFilledIcon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 30,
    height: 30,
    overflow: "hidden",
  },
  like: {
    position: "absolute",
    top: 14,
    left: 282,
    width: 30,
    height: 41,
  },
  share1: {
    position: "absolute",
    top: "62.16%",
    left: "1222.22%",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  iconParkSolidshareTwo: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 25,
    height: 25,
    overflow: "hidden",
  },
  share: {
    position: "absolute",
    top: 17,
    left: 330,
    width: 27,
    height: 37,
  },
  footer: {
    position: "absolute",
    top: 221,
    left: 0,
    width: 361,
    height: 57,
  },
  frame9: {
    position: "relative",
    width: 364,
    height: 278,
    overflow: "hidden",
  },
  frame8: {
    width: 371,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "flex-end",
    justifyContent: "center",
    marginTop: 6,
  },
  frame7: {
    width: 371,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-end",
  },
  homeIcon: {
    position: "relative",
    width: 29,
    height: 32,
    overflow: "hidden",
  },
  home1: {
    position: "relative",
    fontSize: FontSize.size_xs,
    lineHeight: 17,
    fontFamily: FontFamily.caption2,
    color: Color.primary400,
    textAlign: "left",
  },
  home: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  googleMapsIcon: {
    position: "relative",
    width: 36,
    height: 36,
  },
  saved: {
    width: 26,
    height: 59,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginLeft: 40,
  },
  heartIcon: {
    position: "relative",
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  saved1: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    display: "none",
    marginLeft: 40,
  },
  cameraIcon: {
    position: "relative",
    width: 38,
    height: 30,
  },
  cart: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginLeft: 40,
  },
  account: {
    position: "relative",
    fontSize: FontSize.size_xs,
    lineHeight: 17,
    fontFamily: FontFamily.caption2,
    color: Color.colorDarkgray_100,
    textAlign: "left",
  },
  container1: {
    height: 57,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  homeIndicator: {
    position: "absolute",
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.primary900,
    width: 134,
    height: 5,
    display: "none",
  },
  homeindicator: {
    position: "relative",
    backgroundColor: Color.labelPrimary,
    width: 390,
    height: 27,
    marginTop: -4,
  },
  container: {
    backgroundColor: Color.labelPrimary,
    borderStyle: "solid",
    borderColor: Color.colorSienna_100,
    borderTopWidth: 1,
    width: 390,
    height: 86,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
    marginRight: 11,
    marginTop: 28,
  },
  frame6: {
    position: "absolute",
    top: 112,
    left: -13,
    width: 401,
    height: 693,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  news: {
    position: "relative",
    backgroundColor: Color.labelPrimary,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default News;
