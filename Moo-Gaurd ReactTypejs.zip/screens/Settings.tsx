import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const Settings = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.settings}>
      <View style={[styles.container, styles.containerLayout]}>
        <View style={[styles.container1, styles.containerFlexBox]}>
          <Pressable
            style={styles.home}
            onPress={() => navigation.navigate("Homescreen1")}
          >
            <Image
              style={[styles.homeIcon, styles.homeIconLayout]}
              contentFit="cover"
              source={require("../assets/home.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Home</Text>
          </Pressable>
          <Pressable
            style={styles.saved}
            onPress={() => navigation.navigate("Geofencing")}
          >
            <Image
              style={[styles.googleMapsIcon, styles.iconLayout1]}
              contentFit="cover"
              source={require("../assets/google-maps.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Tracking</Text>
          </Pressable>
          <View style={[styles.saved1, styles.savedFlexBox]}>
            <Image
              style={[styles.heartIcon, styles.iconLayout]}
              contentFit="cover"
              source={require("../assets/heart.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Saved</Text>
          </View>
          <Pressable
            style={styles.cart}
            onPress={() => navigation.navigate("Camera")}
          >
            <Image
              style={styles.cameraIcon}
              contentFit="cover"
              source={require("../assets/camera.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Surveillance</Text>
          </Pressable>
          <View style={styles.cart}>
            <Image
              style={[styles.heartIcon, styles.iconLayout]}
              contentFit="cover"
              source={require("../assets/user.png")}
            />
            <Text style={[styles.account, styles.home1Typo]}>Account</Text>
          </View>
        </View>
        <View style={[styles.container2, styles.containerLayout]}>
          <View style={[styles.container3, styles.containerFlexBox]}>
            <View style={styles.savedFlexBox}>
              <Image
                style={[styles.heartIcon, styles.iconLayout]}
                contentFit="cover"
                source={require("../assets/heart2.png")}
              />
              <Text style={[styles.home1, styles.home1Typo]}>Saved</Text>
            </View>
          </View>
          <View style={styles.homeindicator}>
            <View style={[styles.homeIndicator, styles.container1Position]} />
          </View>
        </View>
      </View>
      <Image
        style={[
          styles.fluentpersonFeedback24ReguIcon,
          styles.fluentpersonIconLayout,
        ]}
        contentFit="cover"
        source={require("../assets/fluentpersonfeedback24regular2.png")}
      />
      <Image
        style={styles.tablernotificationIcon}
        contentFit="cover"
        source={require("../assets/tablernotification2.png")}
      />
      <Image
        style={[styles.settingsChild, styles.frameInnerLayout]}
        contentFit="cover"
        source={require("../assets/group-224.png")}
      />
      <View style={[styles.subject2Parent, styles.parentFlexBox]}>
        <Image
          style={styles.subject2Icon}
          contentFit="cover"
          source={require("../assets/subject-21.png")}
        />
        <Text style={styles.mooGuard}>Moo-Guard</Text>
      </View>
      <View
        style={[
          styles.claritylanguageLineParent,
          styles.claritylanguagePosition,
        ]}
      >
        <Image
          style={[styles.claritylanguageLineIcon, styles.frameChildPosition]}
          contentFit="cover"
          source={require("../assets/claritylanguageline.png")}
        />
        <Text style={[styles.selectLanguage, styles.selectTypo]}>
          Select Language
        </Text>
        <View style={styles.englishParent}>
          <Text style={[styles.english, styles.englishTypo]}>English</Text>
          <Image
            style={[styles.frameChild, styles.frameLayout]}
            contentFit="cover"
            source={require("../assets/arrow-4.png")}
          />
        </View>
      </View>
      <View
        style={[
          styles.claritylanguageLineGroup,
          styles.claritylanguagePosition,
        ]}
      >
        <Image
          style={[styles.claritylanguageLineIcon1, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/claritylanguageline1.png")}
        />
        <Text style={[styles.notifications, styles.selectTypo]}>
          Notifications
        </Text>
      </View>
      <View style={[styles.selectLocationParent, styles.aboutUsPosition]}>
        <Text style={styles.selectTypo}>Select Location</Text>
        <View style={styles.windhoekParent}>
          <Text style={[styles.windhoek, styles.englishTypo1]}>Windhoek</Text>
          <Image
            style={[styles.frameItem, styles.frameLayout]}
            contentFit="cover"
            source={require("../assets/arrow-41.png")}
          />
        </View>
      </View>
      <Image
        style={[styles.settingsItem, styles.frameChildLayout]}
        contentFit="cover"
        source={require("../assets/line-6.png")}
      />
      <Image
        style={[styles.settingsInner, styles.frameChildLayout]}
        contentFit="cover"
        source={require("../assets/line-6.png")}
      />
      <Image
        style={[styles.lineIcon, styles.frameChildLayout]}
        contentFit="cover"
        source={require("../assets/line-7.png")}
      />
      <Image
        style={[styles.settingsChild1, styles.frameChildLayout]}
        contentFit="cover"
        source={require("../assets/line-10.png")}
      />
      <Image
        style={[styles.settingsChild2, styles.frameChildLayout]}
        contentFit="cover"
        source={require("../assets/line-7.png")}
      />
      <Image
        style={[styles.settingsChild3, styles.frameChildLayout]}
        contentFit="cover"
        source={require("../assets/line-10.png")}
      />
      <Image
        style={styles.fa6SolidmapLocationDotIcon}
        contentFit="cover"
        source={require("../assets/fa6solidmaplocationdot.png")}
      />
      <View style={styles.darkThemeParent}>
        <Text style={[styles.darkTheme, styles.selectTypo]}>Dark Theme</Text>
        <Image
          style={[styles.heroiconssunSolid, styles.frameChildPosition]}
          contentFit="cover"
          source={require("../assets/heroiconssunsolid.png")}
        />
        <Image
          style={[styles.frameInner, styles.frameInnerLayout]}
          contentFit="cover"
          source={require("../assets/group-245.png")}
        />
      </View>
      <Text style={[styles.aboutUs, styles.aboutUsPosition]}>About us</Text>
      <Image
        style={[styles.settingsChild1, styles.frameChildLayout]}
        contentFit="cover"
        source={require("../assets/line-7.png")}
      />
      <View style={[styles.lineParent, styles.lineLayout]}>
        <Image
          style={[styles.frameChild1, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-11.png")}
        />
        <Text style={[styles.contactUs, styles.selectTypo]}>Contact us</Text>
      </View>
      <View style={[styles.lineGroup, styles.lineGroupLayout]}>
        <Image
          style={[styles.frameChild2, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-111.png")}
        />
        <Text style={[styles.feedback, styles.selectTypo]}>Feedback</Text>
      </View>
      <View style={[styles.lineContainer, styles.lineLayout]}>
        <Image
          style={[styles.frameChild1, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-112.png")}
        />
        <Text style={[styles.referTheApp, styles.rateUsTypo]}>
          Refer the App
        </Text>
        <Image
          style={styles.charmshareIcon}
          contentFit="cover"
          source={require("../assets/charmshare.png")}
        />
      </View>
      <View style={[styles.frameView, styles.lineGroupLayout]}>
        <Image
          style={[styles.frameChild2, styles.frameChildLayout]}
          contentFit="cover"
          source={require("../assets/line-113.png")}
        />
        <Text style={[styles.rateUs, styles.rateUsTypo]}>Rate us</Text>
      </View>
      <View style={styles.lineParent1}>
        <Image
          style={[styles.frameChild5, styles.childPosition]}
          contentFit="cover"
          source={require("../assets/line-114.png")}
        />
        <Text style={[styles.signOut, styles.rateUsTypo]}>Sign out</Text>
        <Image
          style={[styles.akarIconssignOut, styles.claritylanguagePosition]}
          contentFit="cover"
          source={require("../assets/akariconssignout.png")}
        />
      </View>
      <Image
        style={styles.fluentpeopleSearch24RegulaIcon}
        contentFit="cover"
        source={require("../assets/fluentpeoplesearch24regular.png")}
      />
      <Image
        style={[styles.icoutlineHeadsetMicIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/icoutlineheadsetmic.png")}
      />
      <Image
        style={[styles.fluentpersonFeedback24ReguIcon1, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/fluentpersonfeedback24regular3.png")}
      />
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <View style={[styles.settingsParent, styles.parentFlexBox]}>
        <Text style={[styles.settings2, styles.englishTypo]}>Settings</Text>
        <View style={[styles.rectangleView, styles.rectangleViewShadowBox]} />
      </View>
      <View style={[styles.settingsChild5, styles.rectangleViewShadowBox]} />
    </View>
  );
};

const styles = StyleSheet.create({
  containerLayout: {
    height: 86,
    borderTopWidth: 1,
    borderColor: Color.colorSienna_100,
    borderStyle: "solid",
    width: 390,
    left: "50%",
    position: "absolute",
    overflow: "hidden",
    backgroundColor: Color.labelPrimary,
  },
  containerFlexBox: {
    justifyContent: "center",
    height: 57,
    alignItems: "center",
    flexDirection: "row",
  },
  homeIconLayout: {
    width: 29,
    overflow: "hidden",
  },
  home1Typo: {
    textAlign: "left",
    fontFamily: FontFamily.caption2,
    lineHeight: 17,
    fontSize: FontSize.size_xs,
  },
  iconLayout1: {
    width: 36,
    height: 36,
  },
  savedFlexBox: {
    display: "none",
    alignItems: "center",
  },
  iconLayout: {
    width: 24,
    height: 24,
  },
  container1Position: {
    left: "50%",
    position: "absolute",
  },
  fluentpersonIconLayout: {
    height: 33,
    width: 33,
  },
  frameInnerLayout: {
    width: 30,
    position: "absolute",
  },
  parentFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  claritylanguagePosition: {
    left: 9,
    position: "absolute",
  },
  frameChildPosition: {
    left: 0,
    position: "absolute",
  },
  selectTypo: {
    color: Color.colorBlack,
    fontFamily: FontFamily.comfortaaBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    textAlign: "left",
  },
  englishTypo: {
    textAlign: "center",
    fontWeight: "700",
  },
  frameLayout: {
    width: 11,
    top: 9,
    maxHeight: "100%",
    position: "absolute",
  },
  aboutUsPosition: {
    left: 62,
    position: "absolute",
  },
  englishTypo1: {
    fontSize: FontSize.size_mini,
    color: Color.colorBlack,
    fontFamily: FontFamily.comfortaaBold,
    top: 0,
    position: "absolute",
  },
  frameChildLayout: {
    height: 2,
    width: 328,
  },
  lineLayout: {
    height: 37,
    width: 328,
    position: "absolute",
  },
  lineGroupLayout: {
    height: 35,
    width: 328,
    position: "absolute",
  },
  rateUsTypo: {
    left: 67,
    color: Color.colorBlack,
    fontFamily: FontFamily.comfortaaBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    textAlign: "left",
    position: "absolute",
  },
  childPosition: {
    top: 36,
    left: 0,
    position: "absolute",
  },
  iconPosition: {
    left: 17,
    position: "absolute",
    overflow: "hidden",
  },
  rectangleViewShadowBox: {
    backgroundColor: Color.colorSienna_200,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  homeIcon: {
    height: 32,
  },
  home1: {
    color: Color.primary400,
  },
  home: {
    alignItems: "center",
  },
  googleMapsIcon: {
    height: 36,
  },
  saved: {
    width: 26,
    height: 59,
    marginLeft: 40,
    alignItems: "center",
  },
  heartIcon: {
    height: 24,
    overflow: "hidden",
  },
  saved1: {
    marginLeft: 40,
  },
  cameraIcon: {
    width: 38,
    height: 30,
  },
  cart: {
    marginLeft: 40,
    alignItems: "center",
  },
  account: {
    color: Color.colorDarkgray_100,
  },
  container1: {
    marginLeft: -147.5,
    top: 6,
    left: "50%",
    position: "absolute",
  },
  container3: {
    width: 34,
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.primary900,
    width: 134,
    height: 5,
  },
  homeindicator: {
    height: 27,
    marginTop: -4,
    width: 390,
    backgroundColor: Color.labelPrimary,
  },
  container2: {
    marginLeft: -208,
    bottom: -719,
    justifyContent: "flex-end",
    alignItems: "center",
  },
  container: {
    marginLeft: -200.5,
    bottom: 7,
  },
  fluentpersonFeedback24ReguIcon: {
    top: 67,
    left: 296,
    position: "absolute",
    overflow: "hidden",
  },
  tablernotificationIcon: {
    top: 69,
    left: 339,
    width: 31,
    height: 31,
    position: "absolute",
    overflow: "hidden",
  },
  settingsChild: {
    top: 63,
    left: 12,
    height: 29,
  },
  subject2Icon: {
    width: 45,
    height: 36,
  },
  mooGuard: {
    color: Color.colorSienna_100,
    width: 147,
    marginLeft: 11,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    height: 29,
    textAlign: "left",
  },
  subject2Parent: {
    top: 60,
    left: 47,
    width: 203,
    height: 36,
    alignItems: "center",
    position: "absolute",
  },
  claritylanguageLineIcon: {
    top: 0,
    height: 36,
    width: 36,
    overflow: "hidden",
  },
  selectLanguage: {
    left: 59,
    top: 3,
    position: "absolute",
  },
  english: {
    fontSize: FontSize.size_mini,
    color: Color.colorBlack,
    fontFamily: FontFamily.comfortaaBold,
    top: 0,
    position: "absolute",
    left: 274,
  },
  frameChild: {
    left: 68,
  },
  englishParent: {
    width: 68,
    height: 17,
    left: 274,
    top: 6,
    position: "absolute",
  },
  claritylanguageLineParent: {
    top: 169,
    width: 342,
    height: 36,
  },
  claritylanguageLineIcon1: {
    height: 36,
    overflow: "hidden",
  },
  notifications: {
    marginLeft: 23,
  },
  claritylanguageLineGroup: {
    top: 316,
    width: 185,
    height: 36,
    alignItems: "center",
    flexDirection: "row",
  },
  windhoek: {
    left: 199,
    textAlign: "right",
    fontWeight: "700",
  },
  frameItem: {
    left: 90,
  },
  windhoekParent: {
    width: 90,
    marginLeft: -26,
    height: 17,
  },
  selectLocationParent: {
    top: 222,
    width: 289,
    height: 22,
    paddingLeft: 62,
    alignItems: "center",
    flexDirection: "row",
  },
  settingsItem: {
    top: 211,
    left: 13,
    position: "absolute",
  },
  settingsInner: {
    top: 358,
    left: 13,
    position: "absolute",
  },
  lineIcon: {
    top: 259,
    left: 13,
    position: "absolute",
  },
  settingsChild1: {
    top: 406,
    left: 13,
    position: "absolute",
  },
  settingsChild2: {
    top: 308,
    left: 13,
    position: "absolute",
  },
  settingsChild3: {
    top: 455,
    left: 13,
    position: "absolute",
  },
  fa6SolidmapLocationDotIcon: {
    top: 220,
    width: 27,
    left: 15,
    height: 24,
    position: "absolute",
    overflow: "hidden",
  },
  darkTheme: {
    left: 46,
    top: 6,
    position: "absolute",
  },
  heroiconssunSolid: {
    top: 0,
    height: 29,
    width: 29,
    overflow: "hidden",
  },
  frameInner: {
    left: 291,
    height: 16,
    top: 6,
  },
  darkThemeParent: {
    top: 267,
    width: 321,
    left: 13,
    height: 29,
    position: "absolute",
  },
  aboutUs: {
    top: 369,
    color: Color.colorBlack,
    fontFamily: FontFamily.comfortaaBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    textAlign: "left",
  },
  frameChild1: {
    top: 35,
    left: 0,
    position: "absolute",
  },
  contactUs: {
    left: 60,
    top: 0,
    position: "absolute",
  },
  lineParent: {
    top: 420,
    left: 13,
  },
  frameChild2: {
    top: 33,
    left: 0,
    position: "absolute",
  },
  feedback: {
    left: 65,
    top: 0,
    position: "absolute",
  },
  lineGroup: {
    top: 470,
    left: 13,
  },
  referTheApp: {
    top: 2,
  },
  charmshareIcon: {
    left: 4,
    width: 20,
    height: 20,
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  lineContainer: {
    top: 515,
    left: 15,
  },
  rateUs: {
    top: 0,
  },
  frameView: {
    top: 564,
    left: 15,
  },
  frameChild5: {
    height: 2,
    width: 328,
  },
  signOut: {
    top: 3,
  },
  akarIconssignOut: {
    top: 0,
    height: 24,
    width: 24,
    overflow: "hidden",
  },
  lineParent1: {
    top: 608,
    height: 38,
    left: 15,
    width: 328,
    position: "absolute",
  },
  fluentpeopleSearch24RegulaIcon: {
    top: 368,
    left: 16,
    width: 25,
    height: 25,
    position: "absolute",
    overflow: "hidden",
  },
  icoutlineHeadsetMicIcon: {
    top: 417,
    height: 24,
    width: 24,
  },
  fluentpersonFeedback24ReguIcon1: {
    top: 462,
    height: 33,
    width: 33,
  },
  vectorIcon: {
    height: "2.59%",
    width: "5.87%",
    top: "69.21%",
    right: "88.27%",
    bottom: "28.2%",
    left: "5.87%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  settings2: {
    fontSize: FontSize.size_5xl,
    width: 119,
    fontFamily: FontFamily.interBold,
    height: 30,
  },
  rectangleView: {
    borderRadius: Border.br_12xl,
    width: 161,
    marginLeft: -114,
    height: 34,
  },
  settingsParent: {
    top: 126,
    left: 73,
    width: 171,
    paddingLeft: 22,
    height: 34,
    alignItems: "center",
    position: "absolute",
  },
  settingsChild5: {
    width: 375,
    height: 73,
    top: 36,
    left: 0,
    position: "absolute",
  },
  settings: {
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    backgroundColor: Color.labelPrimary,
  },
});

export default Settings;
