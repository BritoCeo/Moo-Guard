import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontFamily, Padding, Color, Border, FontSize } from "../GlobalStyles";

const CreateAccount = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.createAccount}>
      <View style={[styles.frame, styles.frameFlexBox]}>
        <Image
          style={styles.objectsIcon}
          contentFit="cover"
          source={require("../assets/objects2.png")}
        />
        <View style={styles.frame1}>
          <View style={styles.background} />
        </View>
      </View>
      <View style={[styles.frame2, styles.frame2Position]}>
        <View style={[styles.frame3, styles.framePosition]}>
          <View style={styles.headerLayout}>
            <View style={[styles.frame4, styles.frameFlexBox]}>
              <Text style={styles.createAccount1}>Create Account</Text>
            </View>
            <View style={[styles.frame5, styles.headerLayout]}>
              <Text style={[styles.createAnAccount, styles.placeholderTypo]}>
                Create an account, if a new Farmer
              </Text>
            </View>
            <Image
              style={[styles.subject1Icon, styles.frame2Position]}
              contentFit="cover"
              source={require("../assets/subject-12.png")}
            />
          </View>
        </View>
        <View style={[styles.frame6, styles.framePosition]}>
          <View style={styles.socialMedia}>
            <Text style={[styles.orContinueWith, styles.signUpTypo]}>
              Or continue with
            </Text>
            <View style={styles.socialMedia1}>
              <View style={[styles.google, styles.googleFlexBox]}>
                <Image
                  style={styles.googleChild}
                  contentFit="cover"
                  source={require("../assets/frame-13.png")}
                />
              </View>
              <View style={[styles.facebook, styles.googleFlexBox]}>
                <Image
                  style={styles.googleChild}
                  contentFit="cover"
                  source={require("../assets/frame-14.png")}
                />
              </View>
              <View style={[styles.facebook, styles.googleFlexBox]}>
                <Image
                  style={styles.googleChild}
                  contentFit="cover"
                  source={require("../assets/frame-16.png")}
                />
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.frame7, styles.framePosition]}>
          <View style={styles.form}>
            <View>
              <View style={[styles.input, styles.inputSpaceBlock]}>
                <Text style={[styles.placeholder, styles.placeholderTypo]}>
                  Name
                </Text>
              </View>
              <View style={[styles.input1, styles.inputSpaceBlock]}>
                <Text style={[styles.placeholder, styles.placeholderTypo]}>
                  Farm License
                </Text>
              </View>
              <View style={[styles.input1, styles.inputSpaceBlock]}>
                <Text style={[styles.placeholder, styles.placeholderTypo]}>
                  Email
                </Text>
              </View>
              <View style={[styles.input1, styles.inputSpaceBlock]}>
                <Text style={[styles.placeholder, styles.placeholderTypo]}>
                  Password
                </Text>
              </View>
              <View style={[styles.input1, styles.inputSpaceBlock]}>
                <Text style={[styles.placeholder, styles.placeholderTypo]}>
                  Confirm Password
                </Text>
              </View>
            </View>
            <View style={styles.actions}>
              <View style={[styles.buttonactive, styles.buttonsmallFlexBox]}>
                <Pressable onPress={() => navigation.navigate("FarmDetails")}>
                  <Text style={[styles.signUp, styles.signUpTypo]}>
                    Sign up
                  </Text>
                </Pressable>
              </View>
              <View style={[styles.buttonsmall, styles.buttonsmallFlexBox]}>
                <Text style={[styles.button1, styles.signUpTypo]}>
                  Already have an account
                </Text>
              </View>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameFlexBox: {
    justifyContent: "flex-end",
    position: "absolute",
    overflow: "hidden",
  },
  frame2Position: {
    position: "absolute",
    overflow: "hidden",
  },
  framePosition: {
    left: 0,
    justifyContent: "center",
    alignItems: "flex-end",
    position: "absolute",
    overflow: "hidden",
  },
  headerLayout: {
    height: 126,
    width: 326,
  },
  placeholderTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "center",
  },
  signUpTypo: {
    fontFamily: FontFamily.calloutBold,
    fontWeight: "600",
    textAlign: "center",
  },
  googleFlexBox: {
    paddingHorizontal: Padding.p_xl,
    width: 60,
    backgroundColor: Color.colorWhitesmoke_300,
    borderRadius: Border.br_3xs,
    paddingVertical: Padding.p_3xs,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  inputSpaceBlock: {
    paddingBottom: Padding.p_xl,
    paddingRight: Padding.p_16xl,
    paddingTop: Padding.p_xl,
    paddingLeft: Padding.p_xl,
    backgroundColor: Color.colorWhitesmoke_200,
    width: 357,
    borderRadius: Border.br_3xs,
    flexDirection: "row",
    alignItems: "center",
  },
  buttonsmallFlexBox: {
    width: 357,
    paddingHorizontal: Padding.p_xl,
    borderRadius: Border.br_3xs,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  objectsIcon: {
    height: 1417,
    width: 1069,
  },
  background: {
    width: 428,
    height: 926,
  },
  frame1: {
    width: 748,
    marginTop: -1061,
    justifyContent: "center",
    alignItems: "flex-end",
    overflow: "hidden",
  },
  frame: {
    top: -468,
    width: 1069,
    left: -348,
  },
  createAccount1: {
    fontSize: FontSize.size_11xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    textAlign: "center",
    color: Color.colorGray_200,
  },
  frame4: {
    left: 55,
    width: 242,
    height: 117,
    alignItems: "center",
    top: 0,
  },
  createAnAccount: {
    color: Color.colorBlack,
    fontSize: FontSize.size_sm,
    width: 326,
    fontWeight: "500",
  },
  frame5: {
    left: 7,
    alignItems: "center",
    top: 0,
    justifyContent: "flex-end",
    position: "absolute",
    overflow: "hidden",
  },
  subject1Icon: {
    height: "57.14%",
    width: "26.38%",
    top: "0%",
    right: "34.36%",
    bottom: "42.86%",
    left: "39.26%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  frame3: {
    width: 681,
    top: 0,
  },
  orContinueWith: {
    fontSize: FontSize.size_sm,
    color: Color.colorGray_200,
    fontWeight: "600",
  },
  googleChild: {
    width: 24,
    height: 24,
  },
  google: {
    paddingVertical: Padding.p_3xs,
  },
  facebook: {
    marginLeft: 10,
    paddingVertical: Padding.p_3xs,
  },
  socialMedia1: {
    marginTop: 10,
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  socialMedia: {
    alignItems: "center",
  },
  frame6: {
    top: 679,
    width: 626,
  },
  placeholder: {
    fontSize: FontSize.calloutBold_size,
    color: Color.colorDimgray_100,
  },
  input: {
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 2,
  },
  input1: {
    marginTop: 26,
  },
  signUp: {
    fontSize: FontSize.size_xl,
    color: Color.labelPrimary,
  },
  buttonactive: {
    shadowColor: "#cbd6ff",
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    backgroundColor: Color.colorSienna_100,
    paddingVertical: Padding.p_mini,
  },
  button1: {
    color: Color.colorDarkslategray_100,
    fontSize: FontSize.size_sm,
  },
  buttonsmall: {
    marginTop: 15,
    paddingVertical: Padding.p_3xs,
    backgroundColor: Color.labelPrimary,
    width: 357,
  },
  actions: {
    marginTop: 10,
  },
  form: {
    width: 342,
    height: 419,
  },
  frame7: {
    top: 129,
    width: 697,
  },
  frame2: {
    top: 44,
    height: 754,
    width: 697,
    left: -348,
  },
  createAccount: {
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    backgroundColor: Color.labelPrimary,
  },
});

export default CreateAccount;
