import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const CommunityPage = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.communityPage}>
      <View style={styles.frame}>
        <View style={styles.frame1} />
        <View style={styles.frame2}>
          <View style={styles.frame3}>
            <Image
              style={styles.frameIcon}
              contentFit="cover"
              source={require("../assets/frame2.png")}
            />
            <View style={styles.frame4}>
              <View style={styles.frame5} />
              <View style={styles.frame6}>
                <View style={styles.frame7}>
                  <View style={styles.frame8}>
                    <Image
                      style={styles.frameIcon1}
                      contentFit="cover"
                      source={require("../assets/frame3.png")}
                    />
                    <View style={styles.frame9}>
                      <Text style={styles.mooGuard}>Moo-Guard</Text>
                    </View>
                  </View>
                  <Image
                    style={styles.fluentpersonFeedback24ReguIcon}
                    contentFit="cover"
                    source={require("../assets/fluentpersonfeedback24regular.png")}
                  />
                </View>
                <Image
                  style={styles.tablernotificationIcon}
                  contentFit="cover"
                  source={require("../assets/tablernotification.png")}
                />
              </View>
            </View>
          </View>
          <View style={styles.frame10}>
            <View style={styles.frame11}>
              <View style={styles.frame12}>
                <Image
                  style={styles.gissearchPropertieIcon}
                  contentFit="cover"
                  source={require("../assets/gissearchpropertie.png")}
                />
                <Text style={styles.phoneEmail}>Search Alerts</Text>
              </View>
            </View>
            <Text style={styles.phoneEmail1}>The Moo-Guard Alerts !!!</Text>
          </View>
        </View>
      </View>
      <View style={styles.frame13}>
        <View style={styles.frame14}>
          <View style={styles.frame15}>
            <Pressable
              style={styles.frameChild}
              onPress={() => navigation.navigate("News")}
            />
            <Image
              style={styles.frameIcon2}
              contentFit="cover"
              source={require("../assets/frame4.png")}
            />
            <View style={styles.frame16}>
              <Text style={styles.cattleFoundBy}>
                Cattle Found by Community
              </Text>
            </View>
            <View style={styles.frame17}>
              <Text style={styles.withTheHelp}>
                With the help of community the livestock was found.
              </Text>
            </View>
            <Image
              style={styles.frameIcon3}
              contentFit="cover"
              source={require("../assets/frame5.png")}
            />
            <View style={styles.frame18}>
              <View style={styles.faSolidbookReader} />
            </View>
            <View style={styles.frame19}>
              <Text style={styles.text}>76</Text>
            </View>
            <Image
              style={styles.frameIcon4}
              contentFit="cover"
              source={require("../assets/frame6.png")}
            />
            <View style={styles.frame20}>
              <Text style={styles.hoursAgo}>2 Hours ago</Text>
            </View>
            <View style={styles.frame21}>
              <Text style={styles.share}>Share</Text>
            </View>
            <View style={styles.frame22}>
              <View style={styles.latestWrapper}>
                <Text style={styles.latest}>Latest</Text>
              </View>
            </View>
            <Image
              style={styles.frameIcon5}
              contentFit="cover"
              source={require("../assets/frame7.png")}
            />
          </View>
          <View style={styles.frame23}>
            <Image
              style={styles.carCow1}
              contentFit="cover"
              source={require("../assets/car-cow-1.png")}
            />
            <View style={styles.frame24}>
              <View style={styles.frame25}>
                <Text style={styles.lostCattleFound}>
                  Lost Cattle found in Van.
                </Text>
                <View style={styles.hotWrapper}>
                  <Text style={styles.hot}>Hot</Text>
                </View>
              </View>
              <View style={styles.frame26}>
                <Text
                  style={styles.policeAlertedOf}
                >{`Police Alerted of potential theft of cattle, let to two arrest. `}</Text>
                <Text style={styles.text1}>76</Text>
                <Text style={styles.hoursAgo1}>2 Hours ago</Text>
                <Text style={styles.share1}>Share</Text>
                <View style={styles.faSolidbookReader1} />
                <Image
                  style={styles.faRegulareyeIcon}
                  contentFit="cover"
                  source={require("../assets/faregulareye.png")}
                />
                <Image
                  style={styles.frameItem}
                  contentFit="cover"
                  source={require("../assets/ellipse-5.png")}
                />
                <Image
                  style={styles.mingcuteshareForwardLineIcon}
                  contentFit="cover"
                  source={require("../assets/mingcuteshareforwardline.png")}
                />
              </View>
            </View>
          </View>
        </View>
        <View style={styles.frame27}>
          <View style={styles.frame28}>
            <Image
              style={styles.livestockTheftIsCripplingEIcon}
              contentFit="cover"
              source={require("../assets/livestocktheftiscripplingemergingfarmerswhohavecalledonthegovernmenttoassistthemwithbettersecuritymeasures-1.png")}
            />
            <View style={styles.frame29}>
              <View style={styles.frame30}>
                <View style={styles.frame31}>
                  <Text style={styles.lostCattleFound}>Mumbai local train</Text>
                  <View style={styles.latestContainer}>
                    <Text style={styles.latest}>Latest</Text>
                  </View>
                </View>
                <View style={styles.frame32}>
                  <View style={styles.frame33}>
                    <Text style={styles.localTrainServices}>
                      Local train services, considered as the lifeline o
                    </Text>
                    <Image
                      style={styles.frameIcon6}
                      contentFit="cover"
                      source={require("../assets/frame8.png")}
                    />
                  </View>
                  <View style={styles.frame34}>
                    <View style={styles.frame35}>
                      <View style={styles.faSolidbookReader} />
                    </View>
                    <View style={styles.frame36}>
                      <Text style={styles.text}>76</Text>
                    </View>
                    <Image
                      style={styles.frameIcon7}
                      contentFit="cover"
                      source={require("../assets/frame9.png")}
                    />
                    <View style={styles.frame37}>
                      <Text style={styles.hoursAgo}>2 Hours ago</Text>
                    </View>
                    <Image
                      style={styles.frameIcon8}
                      contentFit="cover"
                      source={require("../assets/frame10.png")}
                    />
                    <Text style={styles.share2}>Share</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
          <View style={styles.container}>
            <View style={styles.container1}>
              <Pressable
                style={styles.home}
                onPress={() => navigation.navigate("Homescreen1")}
              >
                <Image
                  style={styles.homeIcon}
                  contentFit="cover"
                  source={require("../assets/home.png")}
                />
                <Text style={styles.home1}>Home</Text>
              </Pressable>
              <Pressable
                style={styles.saved}
                onPress={() => navigation.navigate("Geofencing")}
              >
                <Image
                  style={styles.googleMapsIcon}
                  contentFit="cover"
                  source={require("../assets/google-maps.png")}
                />
                <Text style={styles.home1}>Tracking</Text>
              </Pressable>
              <View style={styles.saved1}>
                <Image
                  style={styles.heartIcon}
                  contentFit="cover"
                  source={require("../assets/heart.png")}
                />
                <Text style={styles.home1}>Saved</Text>
              </View>
              <Pressable
                style={styles.cart}
                onPress={() => navigation.navigate("Camera")}
              >
                <Image
                  style={styles.cameraIcon}
                  contentFit="cover"
                  source={require("../assets/camera.png")}
                />
                <Text style={styles.home1}>Surveillance</Text>
              </Pressable>
              <Pressable
                style={styles.cart}
                onPress={() => navigation.navigate("Settings")}
              >
                <Image
                  style={styles.heartIcon}
                  contentFit="cover"
                  source={require("../assets/user.png")}
                />
                <Text style={styles.account}>Account</Text>
              </Pressable>
            </View>
            <View style={styles.homeindicator}>
              <View style={styles.homeIndicator} />
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frame1: {
    width: 455,
    height: 47,
    overflow: "hidden",
    justifyContent: "center",
    alignItems: "flex-start",
  },
  frameIcon: {
    position: "relative",
    width: 30,
    height: 37,
    overflow: "hidden",
  },
  frame5: {
    position: "relative",
    width: 323,
    height: 40,
    overflow: "hidden",
  },
  frameIcon1: {
    position: "relative",
    width: 45,
    height: 40,
    overflow: "hidden",
  },
  mooGuard: {
    position: "relative",
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorSienna_100,
    textAlign: "left",
    width: 147,
    height: 29,
  },
  frame9: {
    width: 147,
    height: 35,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginLeft: 7,
  },
  frame8: {
    width: 199,
    height: 40,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  fluentpersonFeedback24ReguIcon: {
    position: "relative",
    width: 33,
    height: 33,
    overflow: "hidden",
    marginLeft: 49,
  },
  frame7: {
    width: 282,
    height: 40,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  tablernotificationIcon: {
    position: "relative",
    width: 31,
    height: 31,
    overflow: "hidden",
    marginLeft: 10,
  },
  frame6: {
    width: 323,
    height: 40,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    marginTop: -40,
  },
  frame4: {
    width: 323,
    height: 40,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginLeft: 5,
  },
  frame3: {
    width: 358,
    height: 40,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
    marginLeft: 7,
  },
  gissearchPropertieIcon: {
    position: "relative",
    width: 22,
    height: 22,
    overflow: "hidden",
  },
  phoneEmail: {
    position: "relative",
    fontSize: FontSize.calloutBold_size,
    lineHeight: 23,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorSienna_100,
    textAlign: "left",
    marginLeft: 20,
  },
  frame12: {
    borderRadius: Border.br_9xs,
    borderStyle: "solid",
    borderColor: Color.colorSienna_100,
    borderWidth: 1.5,
    width: 347,
    height: 54,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
    padding: Padding.p_mini,
  },
  frame11: {
    width: 351,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  phoneEmail1: {
    fontSize: 14,
    lineHeight: 23,
    fontWeight: "600",
    fontFamily: FontFamily.openSansSemiBold,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
    height: 24,
    marginRight: 177,
    marginTop: 9,
  },
  frame10: {
    width: 351,
    height: 87,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginTop: 27,
  },
  frame2: {
    width: 365,
    height: 154,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 13,
  },
  frame: {
    position: "absolute",
    top: -13,
    left: -40,
    width: 455,
    height: 214,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  frameChild: {
    position: "absolute",
    top: 0,
    left: 0,
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowRadius: 3,
    elevation: 3,
    shadowOpacity: 1,
    borderRadius: Border.br_5xs,
    backgroundColor: Color.labelPrimary,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro_100,
    borderWidth: 1,
    width: 366,
    height: 112,
  },
  frameIcon2: {
    position: "absolute",
    top: 0,
    left: 16,
    width: 73,
    height: 105,
    overflow: "hidden",
  },
  cattleFoundBy: {
    position: "relative",
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.openSansSemiBold,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  frame16: {
    position: "absolute",
    top: 0,
    left: 125,
    width: 189,
    height: 34,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  withTheHelp: {
    position: "relative",
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
    width: 204,
  },
  frame17: {
    position: "absolute",
    top: 0,
    left: 131,
    width: 204,
    height: 78,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  frameIcon3: {
    position: "absolute",
    top: 0,
    left: 132,
    width: 15,
    height: 98,
    overflow: "hidden",
  },
  faSolidbookReader: {
    position: "relative",
    width: 8,
    height: 8,
    overflow: "hidden",
  },
  frame18: {
    position: "absolute",
    top: 0,
    left: 133,
    width: 8,
    height: 101,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  text: {
    position: "relative",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
    width: 13,
    height: 16,
  },
  frame19: {
    position: "absolute",
    top: 0,
    left: 150,
    width: 13,
    height: 101,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  frameIcon4: {
    position: "absolute",
    top: 0,
    left: 187,
    width: 8,
    height: 96,
    overflow: "hidden",
  },
  hoursAgo: {
    position: "relative",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
    width: 68,
    height: 16,
  },
  frame20: {
    position: "absolute",
    top: 0,
    left: 198,
    width: 68,
    height: 101,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  share: {
    position: "relative",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  frame21: {
    position: "absolute",
    top: 0,
    left: 313,
    width: 27,
    height: 107,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  latest: {
    position: "absolute",
    top: 1,
    left: 328,
    fontSize: FontSize.size_3xs,
    fontWeight: "500",
    fontFamily: FontFamily.interMedium,
    color: Color.colorBlack,
    textAlign: "left",
  },
  latestWrapper: {
    position: "relative",
    borderRadius: Border.br_11xs,
    backgroundColor: Color.colorLime,
    width: 36,
    height: 14,
  },
  frame22: {
    position: "absolute",
    top: 0,
    left: 321,
    width: 36,
    height: 27,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  frameIcon5: {
    position: "absolute",
    top: 0,
    left: 315,
    width: 24,
    height: 96,
    overflow: "hidden",
  },
  frame15: {
    width: 366,
    height: 112,
    overflow: "hidden",
    marginLeft: 1,
  },
  carCow1: {
    position: "relative",
    width: 112,
    height: 100,
  },
  lostCattleFound: {
    position: "relative",
    fontSize: FontSize.calloutBold_size,
    fontWeight: "600",
    fontFamily: FontFamily.openSansSemiBold,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  hot: {
    position: "absolute",
    top: 1,
    left: 334,
    fontSize: FontSize.size_3xs,
    fontWeight: "500",
    fontFamily: FontFamily.interMedium,
    color: Color.labelPrimary,
    textAlign: "left",
  },
  hotWrapper: {
    position: "relative",
    borderRadius: Border.br_11xs,
    backgroundColor: "#ff0000",
    width: 36,
    height: 14,
    marginLeft: 7,
  },
  frame25: {
    width: 237,
    height: 22,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  policeAlertedOf: {
    position: "absolute",
    width: "97.61%",
    top: "0%",
    left: "0%",
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  text1: {
    position: "absolute",
    height: "24.62%",
    width: "6.22%",
    top: "66.15%",
    left: "9.09%",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  hoursAgo1: {
    position: "absolute",
    height: "24.62%",
    width: "32.54%",
    top: "66.15%",
    left: "32.06%",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  share1: {
    position: "absolute",
    top: "78.46%",
    left: "87.08%",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  faSolidbookReader1: {
    position: "absolute",
    top: 51,
    left: 2,
    width: 8,
    height: 8,
    overflow: "hidden",
  },
  faRegulareyeIcon: {
    position: "absolute",
    top: 44,
    left: 1,
    width: 15,
    height: 12,
    overflow: "hidden",
  },
  frameItem: {
    position: "absolute",
    top: 46,
    left: 56,
    width: 8,
    height: 8,
  },
  mingcuteshareForwardLineIcon: {
    position: "absolute",
    top: 30,
    left: 184,
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  frame26: {
    position: "relative",
    width: 209,
    height: 65,
    overflow: "hidden",
    marginTop: 13,
  },
  frame24: {
    width: 237,
    height: 100,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 2,
  },
  frame23: {
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowRadius: 3,
    elevation: 3,
    shadowOpacity: 1,
    borderRadius: Border.br_5xs,
    backgroundColor: Color.labelPrimary,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro_100,
    borderWidth: 1,
    width: 366,
    height: 112,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingHorizontal: Padding.p_7xs,
    paddingVertical: Padding.p_6xs,
    marginLeft: 1,
    marginTop: 10,
  },
  frame14: {
    width: 367,
    height: 234,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  livestockTheftIsCripplingEIcon: {
    position: "relative",
    borderRadius: Border.br_3xs,
    width: 119,
    height: 79,
  },
  latestContainer: {
    position: "relative",
    borderRadius: Border.br_11xs,
    backgroundColor: Color.colorLime,
    width: 36,
    height: 14,
    marginLeft: 43,
  },
  frame31: {
    width: 226,
    height: 25,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
    paddingTop: 3,
  },
  localTrainServices: {
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
    width: 65,
    marginBottom: 29,
  },
  frameIcon6: {
    position: "relative",
    width: 15,
    height: 21,
    overflow: "hidden",
    marginLeft: -203,
  },
  frame33: {
    width: 204,
    height: 65,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  frame35: {
    position: "absolute",
    top: 21,
    left: 0,
    width: 8,
    height: 14,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  frame36: {
    position: "absolute",
    top: 13,
    left: 17,
    width: 13,
    height: 22,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  frameIcon7: {
    position: "absolute",
    top: 16,
    left: 54,
    width: 8,
    height: 19,
    overflow: "hidden",
  },
  frame37: {
    position: "absolute",
    top: 13,
    left: 65,
    width: 68,
    height: 22,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  frameIcon8: {
    position: "absolute",
    top: 0,
    left: 182,
    width: 24,
    height: 35,
    overflow: "hidden",
  },
  share2: {
    position: "absolute",
    top: "60%",
    left: "86.96%",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
  },
  frame34: {
    position: "relative",
    width: 207,
    height: 35,
    overflow: "hidden",
    marginTop: -35,
  },
  frame32: {
    width: 209,
    height: 65,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
    paddingLeft: Padding.p_11xs,
    marginTop: 4,
  },
  frame30: {
    width: 226,
    height: 94,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  frame29: {
    width: 226,
    height: 102,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
    marginLeft: 6,
  },
  frame28: {
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowRadius: 3,
    elevation: 3,
    shadowOpacity: 1,
    borderRadius: Border.br_5xs,
    backgroundColor: Color.labelPrimary,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro_100,
    borderWidth: 1,
    width: 366,
    height: 112,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
    paddingHorizontal: Padding.p_7xs,
    paddingTop: 5,
    marginLeft: 1,
  },
  homeIcon: {
    position: "relative",
    width: 29,
    height: 32,
    overflow: "hidden",
  },
  home1: {
    position: "relative",
    fontSize: FontSize.size_xs,
    lineHeight: 17,
    fontFamily: FontFamily.caption2,
    color: Color.primary400,
    textAlign: "left",
  },
  home: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  googleMapsIcon: {
    position: "relative",
    width: 36,
    height: 36,
  },
  saved: {
    width: 26,
    height: 59,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginLeft: 40,
  },
  heartIcon: {
    position: "relative",
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  saved1: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    display: "none",
    marginLeft: 40,
  },
  cameraIcon: {
    position: "relative",
    width: 38,
    height: 30,
  },
  cart: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginLeft: 40,
  },
  account: {
    position: "relative",
    fontSize: FontSize.size_xs,
    lineHeight: 17,
    fontFamily: FontFamily.caption2,
    color: Color.colorDarkgray_100,
    textAlign: "left",
  },
  container1: {
    height: 57,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  homeIndicator: {
    position: "absolute",
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.primary900,
    width: 134,
    height: 5,
    display: "none",
  },
  homeindicator: {
    position: "relative",
    backgroundColor: Color.labelPrimary,
    width: 390,
    height: 27,
    marginTop: -4,
  },
  container: {
    backgroundColor: Color.labelPrimary,
    borderStyle: "solid",
    borderColor: Color.colorSienna_100,
    borderTopWidth: 1,
    width: 390,
    height: 86,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-end",
    marginRight: 11,
    marginTop: 142,
  },
  frame27: {
    width: 401,
    height: 340,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    marginTop: 10,
  },
  frame13: {
    position: "absolute",
    top: 221,
    left: -13,
    width: 401,
    height: 584,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  communityPage: {
    position: "relative",
    backgroundColor: Color.labelPrimary,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default CommunityPage;
