import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Padding, Border } from "../GlobalStyles";

const Emergency = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.emergency}>
      <View style={styles.policeCarLightParent}>
        <Image
          style={[styles.policeCarLight, styles.policeLayout]}
          contentFit="cover"
          source={require("../assets/police-car-light.png")}
        />
        <Text style={[styles.policeRespones, styles.emergency1Typo]}>
          Police Respones
        </Text>
        <Text style={[styles.emergency1, styles.emergency1Typo]}>
          Emergency
        </Text>
      </View>
      <Text style={[styles.emergencyAlert, styles.countdownTypo]}>
        Emergency Alert!!
      </Text>
      <Text style={[styles.countdown, styles.countdownTypo]}>{`30 
CountDown`}</Text>
      <View style={styles.goBackParent}>
        <View style={[styles.goBack, styles.backSpaceBlock]}>
          <Image
            style={styles.doneIcon}
            contentFit="cover"
            source={require("../assets/done.png")}
          />
        </View>
        <View style={[styles.goBack1, styles.backSpaceBlock]}>
          <Image
            style={styles.closeIcon}
            contentFit="cover"
            source={require("../assets/close.png")}
          />
        </View>
      </View>
      <Image
        style={[styles.policeBadgeIcon, styles.policeLayout]}
        contentFit="cover"
        source={require("../assets/police-badge.png")}
      />
      <View style={[styles.container, styles.containerLayout]}>
        <View style={styles.container1}>
          <Pressable
            style={styles.home}
            onPress={() => navigation.navigate("Homescreen1")}
          >
            <Image
              style={styles.homeIcon}
              contentFit="cover"
              source={require("../assets/home.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Home</Text>
          </Pressable>
          <Pressable
            style={[styles.saved, styles.savedSpaceBlock]}
            onPress={() => navigation.navigate("Geofencing")}
          >
            <Image
              style={styles.googleMapsIcon}
              contentFit="cover"
              source={require("../assets/google-maps.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Tracking</Text>
          </Pressable>
          <View style={[styles.saved1, styles.savedSpaceBlock]}>
            <Image
              style={styles.heartIcon}
              contentFit="cover"
              source={require("../assets/heart.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Saved</Text>
          </View>
          <Pressable
            style={styles.savedSpaceBlock}
            onPress={() => navigation.navigate("Camera")}
          >
            <Image
              style={styles.cameraIcon}
              contentFit="cover"
              source={require("../assets/camera.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Surveillance</Text>
          </Pressable>
          <Pressable
            style={styles.savedSpaceBlock}
            onPress={() => navigation.navigate("Settings")}
          >
            <Image
              style={styles.heartIcon}
              contentFit="cover"
              source={require("../assets/user.png")}
            />
            <Text style={[styles.account, styles.home1Typo]}>Account</Text>
          </Pressable>
        </View>
        <View style={[styles.homeindicator, styles.containerLayout]}>
          <View style={[styles.homeIndicator, styles.containerPosition]} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  policeLayout: {
    height: 100,
    width: 100,
    position: "absolute",
  },
  emergency1Typo: {
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.juraMedium,
    fontWeight: "500",
    fontSize: FontSize.size_6xl,
    left: 0,
    position: "absolute",
  },
  countdownTypo: {
    width: 343,
    textAlign: "center",
    fontSize: FontSize.size_16xl,
    left: 9,
    position: "absolute",
  },
  backSpaceBlock: {
    paddingVertical: 0,
    paddingHorizontal: Padding.p_xs,
    alignItems: "flex-end",
    width: 80,
    borderRadius: Border.br_7xs,
    justifyContent: "center",
  },
  containerLayout: {
    width: 390,
    backgroundColor: Color.labelPrimary,
  },
  home1Typo: {
    fontFamily: FontFamily.caption2,
    lineHeight: 17,
    fontSize: FontSize.size_xs,
    textAlign: "left",
  },
  savedSpaceBlock: {
    marginLeft: 40,
    alignItems: "center",
  },
  containerPosition: {
    left: "50%",
    position: "absolute",
  },
  policeCarLight: {
    top: 241,
    left: 52,
  },
  policeRespones: {
    top: 376,
  },
  emergency1: {
    top: 0,
  },
  policeCarLightParent: {
    top: 243,
    left: 89,
    width: 202,
    height: 400,
    position: "absolute",
  },
  emergencyAlert: {
    top: 54,
    fontWeight: "600",
    fontFamily: FontFamily.calloutBold,
    color: Color.colorSienna_100,
  },
  countdown: {
    top: 334,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: "#ee2a2a",
  },
  doneIcon: {
    width: 52,
    height: 34,
  },
  goBack: {
    backgroundColor: "#3adc7b",
  },
  closeIcon: {
    width: 46,
    height: 30,
  },
  goBack1: {
    backgroundColor: "#dc3a3a",
    marginLeft: 71,
  },
  goBackParent: {
    top: 680,
    left: 76,
    width: 222,
    height: 39,
    alignItems: "center",
    flexDirection: "row",
    position: "absolute",
  },
  policeBadgeIcon: {
    top: 107,
    left: 131,
  },
  homeIcon: {
    width: 29,
    height: 32,
    overflow: "hidden",
  },
  home1: {
    color: Color.primary400,
  },
  home: {
    alignItems: "center",
  },
  googleMapsIcon: {
    width: 36,
    height: 36,
  },
  saved: {
    width: 26,
    height: 59,
  },
  heartIcon: {
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  saved1: {
    display: "none",
  },
  cameraIcon: {
    width: 38,
    height: 30,
  },
  account: {
    color: Color.colorDarkgray_100,
  },
  container1: {
    height: 57,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.primary900,
    width: 134,
    height: 5,
    display: "none",
  },
  homeindicator: {
    height: 27,
    marginTop: -4,
  },
  container: {
    marginLeft: -195.5,
    bottom: 0,
    borderStyle: "solid",
    borderColor: Color.colorSienna_100,
    borderTopWidth: 1,
    height: 86,
    justifyContent: "flex-end",
    overflow: "hidden",
    left: "50%",
    position: "absolute",
    alignItems: "center",
  },
  emergency: {
    flex: 1,
    width: "100%",
    height: 812,
    backgroundColor: Color.labelPrimary,
  },
});

export default Emergency;
