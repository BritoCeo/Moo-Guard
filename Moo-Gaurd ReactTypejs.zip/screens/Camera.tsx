import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Padding, Border } from "../GlobalStyles";

const Camera = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.camera}>
      <View style={[styles.cameraChild, styles.containerBorder]} />
      <View style={styles.cameraBar}>
        <View style={styles.cameraActionBar}>
          <View style={[styles.cameraMicButton, styles.timeline1FlexBox]}>
            <Image
              style={styles.containerIcon}
              contentFit="cover"
              source={require("../assets/container.png")}
            />
          </View>
          <Pressable
            style={[styles.cameraActionButton, styles.cameraLayout]}
            onPress={() => navigation.navigate("Camera1")}
          >
            <Image
              style={styles.cameraActionButtonChild}
              contentFit="cover"
              source={require("../assets/ellipse-71.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.cameraModeButton, styles.cameraFlexBox]}
            onPress={() => navigation.navigate("Emergency")}
          >
            <Text style={styles.text}>􀙨</Text>
          </Pressable>
        </View>
        <View style={styles.timeline}>
          <View style={[styles.timeline1, styles.timeline1Position]}>
            <View style={styles.timelineScale}>
              <View style={[styles.hour, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
            </View>
            <View style={styles.hourParent}>
              <View style={[styles.hour, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
            </View>
            <View style={styles.hourParent}>
              <View style={[styles.hour, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
            </View>
            <View style={styles.hourParent}>
              <View style={[styles.hour, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
            </View>
            <View style={styles.hourParent}>
              <View style={[styles.hour, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
            </View>
            <View style={styles.hourParent}>
              <View style={[styles.hour, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
            </View>
            <View style={styles.hourParent}>
              <View style={[styles.hour, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
            </View>
            <View style={styles.hourParent}>
              <View style={[styles.hour, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
              <View style={[styles.quarter, styles.hourLayout]} />
            </View>
          </View>
          <Text style={[styles.timeStamp, styles.stampTypo]}>12:52:03 PM</Text>
          <Text style={[styles.nounStamp, styles.stampTypo]}>noun</Text>
          <View style={[styles.multicamArchive, styles.timeline1Position]}>
            <View style={[styles.archive, styles.archiveLayout]}>
              <View style={[styles.archiveBackground, styles.archiveLayout]} />
              <View style={[styles.archiveActive, styles.archiveLayout]} />
            </View>
          </View>
          <View style={[styles.nowStamp, styles.hourLayout]} />
        </View>
      </View>
      <Image
        style={[styles.cowCctv1, styles.cowCctv1Layout]}
        contentFit="cover"
        source={require("../assets/cow-cctv-1.png")}
      />
      <View style={styles.navigationBar}>
        <View style={[styles.cameraSettingsParent, styles.containerFlexBox]}>
          <View style={styles.containerIcon}>
            <Text style={[styles.text1, styles.textLayout]}>􀍟</Text>
          </View>
          <View style={[styles.cameraStatusTags, styles.cameraFlexBox]}>
            <View style={styles.moon}>
              <Text style={[styles.icon, styles.iconTypo]}>􀍟</Text>
            </View>
            <Text style={[styles.label, styles.iconTypo]}>UPDATE</Text>
          </View>
        </View>
        <View style={[styles.label1, styles.label1FlexBox]}>
          <Text style={[styles.title, styles.titleTypo]}>Front Door</Text>
          <Text style={[styles.subtitle, styles.titleTypo]}>Subtitle</Text>
        </View>
        <Pressable
          style={styles.parent}
          onPress={() => navigation.navigate("Geofencing")}
        >
          <Text style={[styles.text2, styles.textLayout]}>􀆉</Text>
          <View style={[styles.cameraStatusTags1, styles.cameraSpaceBlock]}>
            <Text style={[styles.label2, styles.iconTypo]}>LIVE</Text>
          </View>
          <View style={[styles.cameraStatusTags2, styles.cameraSpaceBlock]}>
            <View style={styles.moon}>
              <Text style={[styles.icon1, styles.iconTypo]}>􀙇</Text>
            </View>
          </View>
          <View style={[styles.cameraStatusTags3, styles.cameraSpaceBlock]}>
            <Text style={[styles.label2, styles.iconTypo]}>LIVE</Text>
          </View>
          <View style={[styles.cameraStatusTags3, styles.cameraSpaceBlock]}>
            <Text style={[styles.label2, styles.iconTypo]}>LIVE</Text>
          </View>
        </Pressable>
      </View>
      <Image
        style={[styles.screenshot20240425At0941, styles.cowCctv1Layout]}
        contentFit="cover"
        source={require("../assets/screenshot-20240425-at-0941-1.png")}
      />
      <View style={[styles.container, styles.containerLayout]}>
        <View style={[styles.container1, styles.timeline1FlexBox]}>
          <Pressable
            style={styles.home}
            onPress={() => navigation.navigate("Homescreen1")}
          >
            <Image
              style={styles.homeIcon}
              contentFit="cover"
              source={require("../assets/home.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Home</Text>
          </Pressable>
          <Pressable
            style={[styles.saved, styles.savedSpaceBlock]}
            onPress={() => navigation.navigate("Geofencing")}
          >
            <Image
              style={styles.googleMapsIcon}
              contentFit="cover"
              source={require("../assets/google-maps.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Tracking</Text>
          </Pressable>
          <View style={[styles.saved1, styles.savedSpaceBlock]}>
            <Image
              style={styles.containerIcon}
              contentFit="cover"
              source={require("../assets/heart.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Saved</Text>
          </View>
          <View style={styles.savedSpaceBlock}>
            <Image
              style={styles.cameraIcon}
              contentFit="cover"
              source={require("../assets/camera.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Surveillance</Text>
          </View>
          <Pressable
            style={styles.savedSpaceBlock}
            onPress={() => navigation.navigate("Settings")}
          >
            <Image
              style={styles.containerIcon}
              contentFit="cover"
              source={require("../assets/user.png")}
            />
            <Text style={[styles.account, styles.home1Typo]}>Account</Text>
          </Pressable>
        </View>
        <View style={[styles.homeindicator, styles.containerLayout]}>
          <View style={styles.homeIndicator} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  containerBorder: {
    borderTopWidth: 1,
    borderStyle: "solid",
  },
  timeline1FlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  cameraLayout: {
    height: 48,
    width: 48,
    position: "absolute",
  },
  cameraFlexBox: {
    backgroundColor: Color.fillPrimary,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  timeline1Position: {
    top: 60,
    width: 375,
    position: "absolute",
  },
  hourLayout: {
    width: 1,
    borderRightWidth: 1,
    borderStyle: "solid",
  },
  stampTypo: {
    lineHeight: 18,
    fontSize: FontSize.caption2_size,
    letterSpacing: 0,
    textAlign: "center",
    fontFamily: FontFamily.caption2,
    left: "50%",
    position: "absolute",
  },
  archiveLayout: {
    height: 4,
    position: "absolute",
  },
  cowCctv1Layout: {
    width: 372,
    position: "absolute",
  },
  containerFlexBox: {
    justifyContent: "flex-end",
    alignItems: "center",
    position: "absolute",
  },
  textLayout: {
    lineHeight: 22,
    color: Color.labelPrimary,
  },
  iconTypo: {
    textAlign: "left",
    fontFamily: FontFamily.calloutBold,
    fontWeight: "600",
    lineHeight: 18,
    letterSpacing: 0,
    fontSize: FontSize.caption2_size,
  },
  label1FlexBox: {
    height: 22,
    justifyContent: "center",
    alignItems: "center",
  },
  titleTypo: {
    fontFamily: FontFamily.calloutBold,
    fontWeight: "600",
    display: "none",
    letterSpacing: 0,
    textAlign: "center",
  },
  cameraSpaceBlock: {
    marginLeft: 4,
    paddingVertical: Padding.p_11xs,
    paddingHorizontal: Padding.p_5xs,
    backgroundColor: Color.fillPrimary,
    flexDirection: "row",
  },
  containerLayout: {
    width: 390,
    backgroundColor: Color.labelPrimary,
  },
  home1Typo: {
    lineHeight: 17,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    fontFamily: FontFamily.caption2,
  },
  savedSpaceBlock: {
    marginLeft: 40,
    alignItems: "center",
  },
  cameraChild: {
    top: 101,
    left: 13,
    borderColor: "#e6e6e6",
    width: 342,
    height: 1,
    position: "absolute",
  },
  containerIcon: {
    overflow: "hidden",
    height: 24,
    width: 24,
  },
  cameraMicButton: {
    marginTop: -37.5,
    marginLeft: -37.5,
    backgroundColor: Color.colorSienna_100,
    width: 75,
    height: 75,
    padding: Padding.p_5xs,
    borderRadius: Border.br_101xl,
    top: "50%",
    left: "50%",
    position: "absolute",
  },
  cameraActionButtonChild: {
    width: 40,
    height: 40,
  },
  cameraActionButton: {
    marginTop: -24,
    right: 20,
    backgroundColor: Color.colorGhostwhite_200,
    padding: Padding.p_9xs,
    flexDirection: "row",
    borderRadius: Border.br_101xl,
    top: "50%",
  },
  text: {
    fontSize: FontSize.size_5xl,
    lineHeight: 24,
    textAlign: "center",
    color: Color.labelPrimary,
    fontFamily: FontFamily.caption2,
  },
  cameraModeButton: {
    top: 14,
    left: 20,
    borderRadius: Border.br_5xl,
    height: 48,
    width: 48,
    position: "absolute",
  },
  cameraActionBar: {
    top: 132,
    height: 76,
    left: 0,
    width: 375,
    position: "absolute",
  },
  hour: {
    borderColor: Color.colorDarkslategray_300,
    height: 25,
  },
  quarter: {
    borderColor: Color.colorDarkslategray_400,
    height: 9,
    marginLeft: 16,
  },
  timelineScale: {
    borderRadius: Border.br_11xs,
    flexDirection: "row",
    alignItems: "center",
  },
  hourParent: {
    marginLeft: 16,
    borderRadius: Border.br_11xs,
    flexDirection: "row",
    alignItems: "center",
  },
  timeline1: {
    marginLeft: -187.5,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    left: "50%",
  },
  timeStamp: {
    marginLeft: -32.5,
    top: 27,
    color: Color.labelSecondary,
  },
  nounStamp: {
    marginLeft: -68.5,
    bottom: 2,
    color: Color.colorGray_100,
  },
  archiveBackground: {
    left: 123,
    backgroundColor: Color.colorDarkslategray_500,
    width: 63,
    borderRadius: Border.br_11xs,
    top: 0,
  },
  archiveActive: {
    left: 171,
    borderTopLeftRadius: Border.br_11xs,
    borderBottomLeftRadius: Border.br_11xs,
    backgroundColor: Color.accentColor,
    width: 16,
    top: 0,
  },
  archive: {
    top: 10,
    left: 0,
    width: 375,
  },
  multicamArchive: {
    height: 24,
    left: 0,
  },
  nowStamp: {
    marginLeft: -1,
    bottom: 16,
    borderColor: Color.labelPrimary,
    height: 41,
    left: "50%",
    position: "absolute",
  },
  timeline: {
    height: 108,
    top: 0,
    overflow: "hidden",
    left: 0,
    width: 375,
    position: "absolute",
  },
  cameraBar: {
    top: 516,
    left: -1,
    height: 210,
    width: 375,
    position: "absolute",
  },
  cowCctv1: {
    top: 376,
    left: 3,
    height: 167,
  },
  text1: {
    marginTop: -12,
    marginLeft: -12,
    display: "flex",
    fontSize: FontSize.bodyBold_size,
    lineHeight: 22,
    letterSpacing: 0,
    textAlign: "center",
    fontFamily: FontFamily.caption2,
    height: 24,
    width: 24,
    justifyContent: "center",
    alignItems: "center",
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  icon: {
    marginLeft: -6,
    color: Color.accentYellow,
    textAlign: "left",
    marginTop: -9,
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  moon: {
    height: 16,
    width: 16,
    overflow: "hidden",
  },
  label: {
    marginLeft: 3,
    color: Color.accentYellow,
    textAlign: "left",
  },
  cameraStatusTags: {
    paddingLeft: Padding.p_7xs,
    paddingTop: Padding.p_11xs,
    paddingRight: Padding.p_5xs,
    paddingBottom: Padding.p_11xs,
    display: "none",
    borderRadius: Border.br_xs,
    marginLeft: 16,
  },
  cameraSettingsParent: {
    top: 57,
    right: 15,
    flexDirection: "row",
    height: 24,
  },
  title: {
    lineHeight: 22,
    color: Color.labelPrimary,
    fontSize: FontSize.bodyBold_size,
  },
  subtitle: {
    fontSize: FontSize.size_smi,
    lineHeight: 15,
    color: Color.accentGreen,
  },
  label1: {
    marginTop: 12,
    marginLeft: -18.5,
    width: 36,
    left: "50%",
    top: "50%",
    height: 22,
    position: "absolute",
  },
  text2: {
    fontSize: FontSize.size_3xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    letterSpacing: 0,
    textAlign: "center",
  },
  label2: {
    color: Color.labelPrimary,
    textAlign: "left",
  },
  cameraStatusTags1: {
    borderRadius: Border.br_xs,
  },
  icon1: {
    marginLeft: -7.5,
    marginTop: -9,
    left: "50%",
    top: "50%",
    position: "absolute",
    color: Color.labelPrimary,
    textAlign: "left",
  },
  cameraStatusTags2: {
    borderRadius: Border.br_2xs,
    height: 22,
    justifyContent: "center",
    alignItems: "center",
  },
  cameraStatusTags3: {
    display: "none",
    borderRadius: Border.br_xs,
  },
  parent: {
    bottom: 12,
    left: 6,
    flexDirection: "row",
    alignItems: "center",
    position: "absolute",
  },
  navigationBar: {
    height: 91,
    top: 0,
    left: 0,
    width: 375,
    position: "absolute",
  },
  screenshot20240425At0941: {
    top: 145,
    left: 2,
    height: 171,
  },
  homeIcon: {
    width: 29,
    height: 32,
    overflow: "hidden",
  },
  home1: {
    color: Color.primary400,
  },
  home: {
    alignItems: "center",
  },
  googleMapsIcon: {
    height: 36,
    width: 36,
  },
  saved: {
    width: 26,
    height: 59,
  },
  saved1: {
    display: "none",
  },
  cameraIcon: {
    width: 38,
    height: 30,
  },
  account: {
    color: Color.colorDarkgray_100,
  },
  container1: {
    height: 57,
    flexDirection: "row",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.primary900,
    width: 134,
    height: 5,
    display: "none",
    left: "50%",
    position: "absolute",
  },
  homeindicator: {
    height: 27,
    marginTop: -4,
  },
  container: {
    marginLeft: -195.5,
    bottom: 0,
    borderColor: Color.colorSienna_100,
    height: 86,
    justifyContent: "flex-end",
    alignItems: "center",
    position: "absolute",
    overflow: "hidden",
    left: "50%",
    borderTopWidth: 1,
    borderStyle: "solid",
  },
  camera: {
    backgroundColor: Color.colorBlack,
    flex: 1,
    width: "100%",
    height: 812,
  },
});

export default Camera;
