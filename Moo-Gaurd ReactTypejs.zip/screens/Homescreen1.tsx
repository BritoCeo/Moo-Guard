import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const Homescreen1 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.homescreen}>
      <View style={[styles.frame, styles.framePosition]}>
        <View style={styles.frame1}>
          <View style={styles.frame2}>
            <View style={[styles.frameChild, styles.frameBg]} />
            <View style={[styles.image122Parent, styles.frame3Position]}>
              <Image
                style={styles.image122Icon}
                contentFit="cover"
                source={require("../assets/image-122.png")}
              />
              <View style={[styles.frame3, styles.frame3Position]}>
                <View style={styles.dashboardParent}>
                  <Text style={styles.dashboard}>DashBoard</Text>
                  <View style={[styles.frameItem, styles.frameShadowBox]} />
                </View>
                <Text style={[styles.mooGuard, styles.mooGuardTypo]}>
                  Moo-Guard
                </Text>
                <Image
                  style={[styles.subject2Icon, styles.frameChildLayout]}
                  contentFit="cover"
                  source={require("../assets/subject-2.png")}
                />
              </View>
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.frame4, styles.frameLayout2]}>
        <View style={styles.frame5}>
          <View style={styles.frame6}>
            <View style={[styles.frameInner, styles.frameShadowBox]} />
            <Text style={styles.days}>10 days</Text>
            <View style={[styles.rectangleView, styles.frameShadowBox]} />
            <Text style={styles.theftFreeDays}>Theft free Days:</Text>
            <Text style={[styles.okamboroFarm, styles.mooGuardTypo]}>
              Okamboro Farm
            </Text>
          </View>
        </View>
        <View style={[styles.frame7, styles.frameLayout1]}>
          <View style={[styles.frame8, styles.frame8Layout]}>
            <View style={styles.frameView}>
              <View style={[styles.groupParent, styles.mapMarkerPosition]}>
                <Image
                  style={[styles.groupIcon, styles.groupIconPosition]}
                  contentFit="cover"
                  source={require("../assets/group-17813.png")}
                />
                <View
                  style={[styles.maskGroupParent, styles.groupIconPosition]}
                >
                  <Image
                    style={[styles.maskGroupIcon, styles.groupIconPosition]}
                    contentFit="cover"
                    source={require("../assets/mask-group.png")}
                  />
                  <Image
                    style={[styles.frameChild1, styles.frameChildLayout]}
                    contentFit="cover"
                    source={require("../assets/group-17481.png")}
                  />
                  <View style={[styles.frameParent, styles.parentLayout]}>
                    <View
                      style={[
                        styles.okamboroLivestockStolenParent,
                        styles.parentLayout,
                      ]}
                    >
                      <Text
                        style={[
                          styles.okamboroLivestockStolen,
                          styles.theEnvironmentalImpactTypo,
                        ]}
                      >
                        Okamboro Livestock Stolen !!
                      </Text>
                      <Image
                        style={styles.frameChild2}
                        contentFit="cover"
                        source={require("../assets/group-17801.png")}
                      />
                    </View>
                    <View style={styles.namlistWrapper}>
                      <Text style={[styles.namlist, styles.minsTypo]}>
                        Namlist
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={[styles.frameGroup, styles.frameGroupLayout]}>
                  <View
                    style={[
                      styles.theEnvironmentalImpactOfLiParent,
                      styles.thePosition,
                    ]}
                  >
                    <Text
                      style={[
                        styles.theEnvironmentalImpact,
                        styles.thePosition,
                      ]}
                    >
                      The Environmental Impact of Livestock
                    </Text>
                    <Image
                      style={styles.frameChild3}
                      contentFit="cover"
                      source={require("../assets/group-178011.png")}
                    />
                  </View>
                  <View style={[styles.farmeduParent, styles.frameGroupLayout]}>
                    <Text style={[styles.farmedu, styles.minsTypo]}>
                      FarmEdu
                    </Text>
                    <Text style={[styles.mins, styles.minsTypo]}>
                      10-15 mins
                    </Text>
                    <Image
                      style={[styles.frameChild4, styles.frameChildLayout]}
                      contentFit="cover"
                      source={require("../assets/group-17503.png")}
                    />
                  </View>
                </View>
              </View>
            </View>
            <View style={styles.communalAlertsWrapper}>
              <Text style={[styles.communalAlerts, styles.iconLayout]}>
                Communal Alerts !
              </Text>
            </View>
            <View style={[styles.homeindicator, styles.homeindicatorLayout]}>
              <View
                style={[styles.homeIndicator, styles.homeindicatorPosition]}
              />
            </View>
            <View style={styles.frame9}>
              <View style={[styles.container, styles.frame8Layout]}>
                <View style={styles.container1}>
                  <Pressable
                    style={styles.home}
                    onPress={() => navigation.navigate("Homescreen1")}
                  >
                    <Image
                      style={styles.homeIcon}
                      contentFit="cover"
                      source={require("../assets/home.png")}
                    />
                    <Text style={[styles.home1, styles.home1Typo]}>Home</Text>
                  </Pressable>
                  <Pressable
                    style={[styles.saved, styles.savedSpaceBlock]}
                    onPress={() => navigation.navigate("Geofencing")}
                  >
                    <Image
                      style={styles.googleMapsIcon}
                      contentFit="cover"
                      source={require("../assets/google-maps.png")}
                    />
                    <Text style={[styles.home1, styles.home1Typo]}>
                      Tracking
                    </Text>
                  </Pressable>
                  <View style={[styles.saved1, styles.savedSpaceBlock]}>
                    <Image
                      style={styles.heartIcon}
                      contentFit="cover"
                      source={require("../assets/heart.png")}
                    />
                    <Text style={[styles.home1, styles.home1Typo]}>Saved</Text>
                  </View>
                  <Pressable
                    style={styles.savedSpaceBlock}
                    onPress={() => navigation.navigate("Camera")}
                  >
                    <Image
                      style={styles.cameraIcon}
                      contentFit="cover"
                      source={require("../assets/camera.png")}
                    />
                    <Text style={[styles.home1, styles.home1Typo]}>
                      Surveillance
                    </Text>
                  </Pressable>
                  <Pressable
                    style={styles.savedSpaceBlock}
                    onPress={() => navigation.navigate("Settings")}
                  >
                    <Image
                      style={styles.heartIcon}
                      contentFit="cover"
                      source={require("../assets/user.png")}
                    />
                    <Text style={[styles.account, styles.home1Typo]}>
                      Account
                    </Text>
                  </Pressable>
                </View>
                <View
                  style={[styles.homeindicator1, styles.homeindicatorLayout]}
                >
                  <View
                    style={[styles.homeIndicator, styles.homeindicatorPosition]}
                  />
                </View>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.frame10, styles.frameLayout]}>
          <View style={[styles.frame11, styles.frameLayout]}>
            <View style={[styles.frameChild5, styles.frameChildShadowBox]} />
            <View style={[styles.frameChild6, styles.frameChildShadowBox]} />
            <Text style={[styles.aiSurveillance, styles.liveTrackingTypo]}>
              Ai Surveillance
            </Text>
            <Pressable
              style={styles.bulletCamera}
              onPress={() => navigation.navigate("Camera")}
            >
              <Image
                style={styles.iconLayout}
                contentFit="cover"
                source={require("../assets/bullet-camera.png")}
              />
            </Pressable>
            <Text style={[styles.liveTracking, styles.liveTrackingTypo]}>
              Live-Tracking
            </Text>
            <Pressable
              style={[styles.mapMarker, styles.mapMarkerPosition]}
              onPress={() => navigation.navigate("Geofencing")}
            >
              <Image
                style={styles.iconLayout}
                contentFit="cover"
                source={require("../assets/map-marker.png")}
              />
            </Pressable>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  framePosition: {
    left: -31,
    position: "absolute",
  },
  frameBg: {
    backgroundColor: Color.colorSienna_200,
    top: 0,
  },
  frame3Position: {
    height: 132,
    left: 0,
    position: "absolute",
  },
  frameShadowBox: {
    borderRadius: Border.br_12xl,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  mooGuardTypo: {
    textAlign: "left",
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
  },
  frameChildLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  frameLayout2: {
    width: 408,
    overflow: "hidden",
  },
  frameLayout1: {
    height: 334,
    position: "absolute",
  },
  frame8Layout: {
    width: 390,
    overflow: "hidden",
  },
  mapMarkerPosition: {
    top: 16,
    left: 15,
    position: "absolute",
  },
  groupIconPosition: {
    width: 270,
    top: 0,
    position: "absolute",
  },
  parentLayout: {
    height: 38,
    width: 224,
    position: "absolute",
  },
  theEnvironmentalImpactTypo: {
    height: 16,
    fontFamily: FontFamily.lexendSemiBold,
    fontWeight: "600",
    color: Color.colorBlack,
    textAlign: "left",
  },
  minsTypo: {
    color: Color.colorSlategray,
    fontFamily: FontFamily.lexendRegular,
    height: 13,
    textAlign: "left",
    position: "absolute",
  },
  frameGroupLayout: {
    width: 171,
    position: "absolute",
  },
  thePosition: {
    width: 155,
    left: 1,
    top: 0,
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  homeindicatorLayout: {
    height: 27,
    width: 390,
    backgroundColor: Color.labelPrimary,
  },
  homeindicatorPosition: {
    left: "50%",
    position: "absolute",
  },
  home1Typo: {
    fontFamily: FontFamily.caption2,
    lineHeight: 17,
    fontSize: FontSize.size_xs,
    textAlign: "left",
  },
  savedSpaceBlock: {
    marginLeft: 40,
    alignItems: "center",
  },
  frameLayout: {
    height: 163,
    position: "absolute",
    overflow: "hidden",
  },
  frameChildShadowBox: {
    height: 123,
    width: 129,
    borderRadius: Border.br_12xl,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  liveTrackingTypo: {
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_mini,
    color: Color.colorBlack,
    textAlign: "center",
    position: "absolute",
  },
  frameChild: {
    height: 73,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    left: 0,
    elevation: 4,
    shadowRadius: 4,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorSienna_200,
    width: 375,
    position: "absolute",
  },
  image122Icon: {
    top: 7,
    left: 314,
    borderRadius: Border.br_29xl,
    width: 48,
    height: 45,
    position: "absolute",
  },
  dashboard: {
    height: "70.73%",
    top: "7.32%",
    left: "23.4%",
    textAlign: "center",
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    fontSize: FontSize.size_5xl,
    position: "absolute",
    width: "100%",
  },
  frameItem: {
    left: 67,
    width: 233,
    height: 41,
    backgroundColor: Color.colorSienna_200,
    top: 0,
  },
  dashboardParent: {
    top: 91,
    left: 6,
    width: 249,
    height: 41,
    position: "absolute",
  },
  mooGuard: {
    height: "21.97%",
    width: "47.92%",
    top: "16.67%",
    left: "32.41%",
    color: Color.colorSienna_100,
    textAlign: "left",
    fontSize: FontSize.size_5xl,
  },
  subject2Icon: {
    height: "52.27%",
    width: "26.38%",
    right: "73.62%",
    bottom: "47.73%",
    left: "0%",
    top: "0%",
    maxWidth: "100%",
  },
  frame3: {
    width: 307,
    top: 0,
    overflow: "hidden",
  },
  image122Parent: {
    top: 2,
    width: 362,
  },
  frame2: {
    left: 31,
    width: 375,
    height: 134,
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  frame1: {
    top: 28,
    width: 406,
    height: 134,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  frame: {
    width: 432,
    height: 181,
    top: 0,
    overflow: "hidden",
  },
  frameInner: {
    top: -1,
    width: 137,
    backgroundColor: Color.colorWhitesmoke_100,
    height: 41,
    left: 0,
  },
  days: {
    top: 19,
    left: 17,
    fontSize: FontSize.size_sm,
    height: 19,
    width: 112,
    textAlign: "left",
    color: Color.colorSienna_100,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
  },
  rectangleView: {
    top: 1,
    left: 176,
    width: 159,
    height: 37,
    backgroundColor: Color.colorWhitesmoke_100,
  },
  theftFreeDays: {
    top: 10,
    color: Color.colorBlack,
    left: 15,
    fontSize: FontSize.size_3xs,
    height: 19,
    width: 112,
    textAlign: "left",
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
  },
  okamboroFarm: {
    top: 9,
    left: 188,
    fontSize: FontSize.calloutBold_size,
    color: "#8f7b6c",
    width: 132,
    height: 19,
  },
  frame6: {
    left: 41,
    width: 335,
    height: 41,
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  frame5: {
    width: 376,
    height: 41,
    left: 0,
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  groupIcon: {
    left: 286,
    height: 191,
  },
  maskGroupIcon: {
    height: 114,
    left: 0,
  },
  frameChild1: {
    height: "12.23%",
    width: "10.51%",
    top: "4.39%",
    right: "3.77%",
    bottom: "83.39%",
    left: "85.71%",
  },
  okamboroLivestockStolen: {
    fontSize: FontSize.size_mini,
    height: 16,
    width: 224,
    left: 0,
    top: 0,
    position: "absolute",
  },
  frameChild2: {
    top: 30,
    left: 61,
    width: 10,
    height: 8,
    position: "absolute",
  },
  okamboroLivestockStolenParent: {
    left: 0,
    top: 0,
  },
  namlist: {
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.lexendRegular,
    width: 77,
    left: 2,
    top: 0,
  },
  namlistWrapper: {
    top: 25,
    height: 13,
    width: 77,
    left: 2,
    position: "absolute",
  },
  frameParent: {
    top: 128,
    left: 11,
  },
  maskGroupParent: {
    shadowColor: "rgba(211, 209, 216, 0.25)",
    shadowRadius: 30,
    elevation: 30,
    borderRadius: Border.br_mini,
    backgroundColor: "rgba(109, 66, 42, 0.13)",
    height: 191,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    left: 0,
    width: 270,
  },
  theEnvironmentalImpact: {
    height: 16,
    fontFamily: FontFamily.lexendSemiBold,
    fontWeight: "600",
    color: Color.colorBlack,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    left: 1,
  },
  frameChild3: {
    top: 34,
    left: 56,
    width: 14,
    height: 12,
    position: "absolute",
  },
  theEnvironmentalImpactOfLiParent: {
    height: 46,
  },
  farmedu: {
    top: 6,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.lexendRegular,
    width: 77,
    left: 0,
  },
  mins: {
    left: 12,
    fontSize: FontSize.size_smi,
    width: 68,
    top: 0,
  },
  frameChild4: {
    height: "54.59%",
    width: "6.39%",
    top: "9.19%",
    right: "40.66%",
    bottom: "36.22%",
    left: "52.96%",
  },
  farmeduParent: {
    top: 26,
    height: 19,
    left: 0,
  },
  frameGroup: {
    top: 124,
    left: 298,
    height: 46,
  },
  groupParent: {
    width: 556,
    height: 191,
  },
  frameView: {
    top: 13,
    left: 10,
    width: 365,
    height: 266,
    position: "absolute",
  },
  communalAlerts: {
    left: "6.06%",
    fontSize: FontSize.size_lg,
    color: "#323643",
    fontFamily: FontFamily.lexendSemiBold,
    fontWeight: "600",
    height: "100%",
    top: "0%",
    textAlign: "left",
    position: "absolute",
  },
  communalAlertsWrapper: {
    left: 25,
    width: 198,
    height: 20,
    top: 0,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.primary900,
    width: 134,
    height: 5,
    display: "none",
  },
  homeindicator: {
    marginLeft: -195,
    bottom: 0,
    left: "50%",
    position: "absolute",
  },
  homeIcon: {
    width: 29,
    height: 32,
    overflow: "hidden",
  },
  home1: {
    color: Color.primary400,
  },
  home: {
    alignItems: "center",
  },
  googleMapsIcon: {
    width: 36,
    height: 36,
  },
  saved: {
    width: 26,
    height: 59,
  },
  heartIcon: {
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  saved1: {
    display: "none",
  },
  cameraIcon: {
    width: 38,
    height: 30,
  },
  account: {
    color: Color.colorDarkgray_100,
  },
  container1: {
    height: 57,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  homeindicator1: {
    marginTop: -4,
  },
  container: {
    borderStyle: "solid",
    borderColor: Color.colorSienna_100,
    borderTopWidth: 1,
    height: 86,
    justifyContent: "flex-end",
    alignItems: "center",
    backgroundColor: Color.labelPrimary,
    width: 390,
  },
  frame9: {
    top: 254,
    width: 401,
    justifyContent: "center",
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  frame8: {
    left: 18,
    height: 334,
    position: "absolute",
    top: 0,
  },
  frame7: {
    top: 269,
    width: 408,
    overflow: "hidden",
    left: 0,
  },
  frameChild5: {
    top: 4,
    backgroundColor: Color.colorWhitesmoke_200,
    left: 0,
  },
  frameChild6: {
    left: 187,
    backgroundColor: Color.colorWhitesmoke_100,
    top: 0,
  },
  aiSurveillance: {
    top: 130,
    left: 194,
    width: 109,
    height: 18,
  },
  bulletCamera: {
    left: 179,
    width: 138,
    height: 130,
    top: 0,
    position: "absolute",
  },
  liveTracking: {
    top: 134,
    left: 7,
    width: 125,
    height: 29,
  },
  mapMarker: {
    width: 100,
    height: 100,
  },
  frame11: {
    left: 50,
    width: 317,
    top: 0,
  },
  frame10: {
    top: 74,
    width: 367,
    left: 0,
  },
  frame4: {
    top: 202,
    height: 603,
    left: -31,
    position: "absolute",
  },
  homescreen: {
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.labelPrimary,
  },
});

export default Homescreen1;
