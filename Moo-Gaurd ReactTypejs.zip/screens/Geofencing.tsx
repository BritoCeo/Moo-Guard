import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Pressable, View, Text } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const Geofencing = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.geofencing}>
      <Image
        style={styles.community1Icon}
        contentFit="cover"
        source={require("../assets/community-1.png")}
      />
      <View style={styles.ellipseParent}>
        <Image
          style={[styles.frameChild, styles.frameChildPosition1]}
          contentFit="cover"
          source={require("../assets/ellipse-263.png")}
        />
        <Pressable
          style={styles.wrapper}
          onPress={() => navigation.navigate("Homescreen1")}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/group-100.png")}
          />
        </Pressable>
        <View style={styles.frameItem} />
        <Image
          style={[styles.frameInner, styles.frameInnerPosition]}
          contentFit="cover"
          source={require("../assets/group-7.png")}
        />
        <Text style={styles.search}>Search...</Text>
      </View>
      <Image
        style={styles.image122Icon}
        contentFit="cover"
        source={require("../assets/image-1221.png")}
      />
      <Image
        style={[styles.geofencingChild, styles.geofencingLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-266.png")}
      />
      <Image
        style={[styles.geofencingItem, styles.geofencingLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-266.png")}
      />
      <View style={[styles.scrollHerd, styles.frameChildPosition1]}>
        <View style={[styles.frameParent, styles.container1FlexBox]}>
          <View style={styles.parentShadowBox}>
            <Text style={[styles.goatLocated, styles.goatLocatedPosition]}>
              Goat Located !
            </Text>
            <Image
              style={[styles.rectangleIcon, styles.frameInnerPosition]}
              contentFit="cover"
              source={require("../assets/rectangle-471.png")}
            />
            <Image
              style={[styles.groupIcon, styles.frameChildLayout1]}
              contentFit="cover"
              source={require("../assets/group-128.png")}
            />
            <Image
              style={[styles.frameChild1, styles.frameChildLayout1]}
              contentFit="cover"
              source={require("../assets/group-128.png")}
            />
            <Image
              style={[styles.frameChild2, styles.frameChildLayout1]}
              contentFit="cover"
              source={require("../assets/group-128.png")}
            />
            <Image
              style={[styles.frameChild3, styles.frameChildLayout1]}
              contentFit="cover"
              source={require("../assets/group-128.png")}
            />
            <Image
              style={[styles.frameChild4, styles.frameChildLayout1]}
              contentFit="cover"
              source={require("../assets/group-128.png")}
            />
            <Text style={[styles.inspectedByFarmspect, styles.kmDariKamuTypo]}>
              Inspected by Farmspect
            </Text>
            <Text style={[styles.kmAway, styles.kmAwayTypo]}>1,7km away</Text>
            <Image
              style={[styles.ellipseIcon, styles.ellipseIconLayout]}
              contentFit="cover"
              source={require("../assets/ellipse-264.png")}
            />
            <Image
              style={[styles.frameChild5, styles.frameChildLayout]}
              contentFit="cover"
              source={require("../assets/group-134.png")}
            />
          </View>
          <View style={[styles.peternakSugiParent, styles.parentShadowBox]}>
            <Text style={[styles.peternakSugi, styles.goatLocatedPosition]}>
              Peternak Sugi
            </Text>
            <Image
              style={[styles.rectangleIcon, styles.frameInnerPosition]}
              contentFit="cover"
              source={require("../assets/rectangle-4711.png")}
            />
            <Image
              style={[styles.frameChild7, styles.frameChildPosition]}
              contentFit="cover"
              source={require("../assets/group-1281.png")}
            />
            <Image
              style={[styles.frameChild8, styles.frameChildPosition]}
              contentFit="cover"
              source={require("../assets/group-1281.png")}
            />
            <Image
              style={[styles.frameChild9, styles.frameChildPosition]}
              contentFit="cover"
              source={require("../assets/group-1281.png")}
            />
            <Image
              style={[styles.frameChild10, styles.frameChildPosition]}
              contentFit="cover"
              source={require("../assets/group-1281.png")}
            />
            <Text style={[styles.inspectedByFarms, styles.kmAwayTypo]}>
              Inspected by Farms
            </Text>
            <Text style={[styles.kmDariKamu, styles.kmDariKamuTypo]}>
              1.1km dari kamu
            </Text>
            <Image
              style={[styles.frameChild11, styles.ellipseIconLayout]}
              contentFit="cover"
              source={require("../assets/ellipse-264.png")}
            />
            <Image
              style={[styles.frameChild12, styles.frameChildLayout]}
              contentFit="cover"
              source={require("../assets/group-1341.png")}
            />
          </View>
        </View>
      </View>
      <View style={[styles.container, styles.containerLayout]}>
        <View style={[styles.container1, styles.container1FlexBox]}>
          <Pressable
            style={styles.home}
            onPress={() => navigation.navigate("Homescreen1")}
          >
            <Image
              style={styles.homeIcon}
              contentFit="cover"
              source={require("../assets/home.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Home</Text>
          </Pressable>
          <View style={[styles.saved, styles.savedSpaceBlock]}>
            <Image
              style={styles.googleMapsIcon}
              contentFit="cover"
              source={require("../assets/google-maps.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Tracking</Text>
          </View>
          <View style={[styles.saved1, styles.savedSpaceBlock]}>
            <Image
              style={styles.heartIcon}
              contentFit="cover"
              source={require("../assets/heart.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Saved</Text>
          </View>
          <Pressable
            style={styles.savedSpaceBlock}
            onPress={() => navigation.navigate("Camera")}
          >
            <Image
              style={styles.cameraIcon}
              contentFit="cover"
              source={require("../assets/camera.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Surveillance</Text>
          </Pressable>
          <Pressable
            style={styles.savedSpaceBlock}
            onPress={() => navigation.navigate("Settings")}
          >
            <Image
              style={styles.heartIcon}
              contentFit="cover"
              source={require("../assets/user.png")}
            />
            <Text style={[styles.account, styles.home1Typo]}>Account</Text>
          </Pressable>
        </View>
        <View style={[styles.homeindicator, styles.containerLayout]}>
          <View style={[styles.homeIndicator, styles.containerPosition]} />
        </View>
      </View>
      <Image
        style={[styles.mapsIcon, styles.mapsIconLayout]}
        contentFit="cover"
        source={require("../assets/maps.png")}
      />
      <Image
        style={[styles.mapsIcon1, styles.mapsIconLayout]}
        contentFit="cover"
        source={require("../assets/maps.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  frameChildPosition1: {
    left: 0,
    position: "absolute",
  },
  frameInnerPosition: {
    top: 13,
    position: "absolute",
  },
  geofencingLayout: {
    height: 186,
    width: 185,
    position: "absolute",
  },
  container1FlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  goatLocatedPosition: {
    top: 19,
    color: Color.colorBlack,
    left: 109,
    textAlign: "left",
    fontSize: FontSize.calloutBold_size,
    position: "absolute",
  },
  frameChildLayout1: {
    height: 14,
    width: 14,
    position: "absolute",
  },
  kmDariKamuTypo: {
    fontSize: FontSize.caption2_size,
    left: 109,
    textAlign: "left",
    fontFamily: FontFamily.caption2,
    position: "absolute",
  },
  kmAwayTypo: {
    fontSize: FontSize.size_xs,
    textAlign: "left",
    fontFamily: FontFamily.caption2,
    position: "absolute",
  },
  ellipseIconLayout: {
    height: 34,
    width: 34,
    position: "absolute",
  },
  frameChildLayout: {
    height: 16,
    width: 16,
    position: "absolute",
  },
  parentShadowBox: {
    width: 271,
    borderRadius: Border.br_mini,
    height: 166,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.05)",
    backgroundColor: Color.labelPrimary,
  },
  frameChildPosition: {
    top: 74,
    height: 14,
    width: 14,
    position: "absolute",
  },
  containerLayout: {
    width: 390,
    backgroundColor: Color.labelPrimary,
  },
  home1Typo: {
    lineHeight: 17,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    fontFamily: FontFamily.caption2,
  },
  savedSpaceBlock: {
    marginLeft: 40,
    alignItems: "center",
  },
  containerPosition: {
    left: "50%",
    position: "absolute",
  },
  mapsIconLayout: {
    height: 100,
    width: 100,
    position: "absolute",
  },
  community1Icon: {
    top: -23,
    left: -608,
    width: 1201,
    position: "absolute",
    height: 812,
  },
  frameChild: {
    width: 48,
    top: 0,
    left: 0,
    height: 48,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 10,
    top: 10,
    width: 28,
    height: 28,
    position: "absolute",
  },
  frameItem: {
    top: 1,
    left: 64,
    borderRadius: 23,
    width: 226,
    height: 46,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.05)",
    position: "absolute",
    backgroundColor: Color.labelPrimary,
  },
  frameInner: {
    left: 79,
    width: 22,
    height: 22,
  },
  search: {
    top: 11,
    left: 110,
    lineHeight: 26,
    textAlign: "left",
    fontFamily: FontFamily.caption2,
    fontSize: FontSize.calloutBold_size,
    color: Color.colorDarkgray_200,
    position: "absolute",
  },
  ellipseParent: {
    left: 3,
    width: 290,
    height: 48,
    top: 44,
    position: "absolute",
  },
  image122Icon: {
    top: 46,
    left: 313,
    borderRadius: Border.br_29xl,
    width: 45,
    height: 45,
    position: "absolute",
  },
  geofencingChild: {
    top: 92,
    left: 177,
  },
  geofencingItem: {
    top: 345,
    left: 51,
  },
  goatLocated: {
    fontWeight: "600",
    fontFamily: FontFamily.calloutBold,
    color: Color.colorBlack,
    left: 109,
  },
  rectangleIcon: {
    left: 12,
    borderRadius: Border.br_5xs,
    width: 80,
    height: 140,
  },
  groupIcon: {
    top: 61,
    height: 14,
    width: 14,
    left: 109,
  },
  frameChild1: {
    left: 126,
    top: 61,
    height: 14,
    width: 14,
  },
  frameChild2: {
    left: 143,
    top: 61,
    height: 14,
    width: 14,
  },
  frameChild3: {
    top: 60,
    left: 176,
  },
  frameChild4: {
    left: 160,
    top: 61,
    height: 14,
    width: 14,
  },
  inspectedByFarmspect: {
    color: Color.colorDarkgray_200,
    fontSize: FontSize.caption2_size,
    top: 44,
  },
  kmAway: {
    top: 121,
    color: Color.colorBlack,
    left: 109,
  },
  ellipseIcon: {
    top: 112,
    left: 220,
  },
  frameChild5: {
    left: 229,
    top: 121,
  },
  peternakSugi: {
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorBlack,
    left: 109,
  },
  frameChild7: {
    left: 109,
  },
  frameChild8: {
    left: 126,
  },
  frameChild9: {
    left: 143,
  },
  frameChild10: {
    left: 160,
  },
  inspectedByFarms: {
    top: 47,
    left: 406,
    color: "rgba(0, 0, 0, 0.5)",
  },
  kmDariKamu: {
    top: 118,
    color: Color.colorBlack,
  },
  frameChild11: {
    top: 105,
    left: 219,
  },
  frameChild12: {
    top: 114,
    left: 228,
  },
  peternakSugiParent: {
    marginLeft: 26,
  },
  frameParent: {
    left: 4,
    width: 568,
    alignItems: "center",
    height: 166,
    flexDirection: "row",
    top: 0,
    position: "absolute",
  },
  scrollHerd: {
    top: 552,
    width: 383,
    height: 174,
  },
  homeIcon: {
    width: 29,
    height: 32,
    overflow: "hidden",
  },
  home1: {
    color: Color.primary400,
  },
  home: {
    alignItems: "center",
  },
  googleMapsIcon: {
    width: 36,
    height: 36,
  },
  saved: {
    width: 26,
    height: 59,
  },
  heartIcon: {
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  saved1: {
    display: "none",
  },
  cameraIcon: {
    width: 38,
    height: 30,
  },
  account: {
    color: Color.colorDarkgray_100,
  },
  container1: {
    height: 57,
    justifyContent: "center",
    alignItems: "center",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.primary900,
    width: 134,
    height: 5,
    display: "none",
  },
  homeindicator: {
    height: 27,
    marginTop: -4,
  },
  container: {
    marginLeft: -195.5,
    bottom: 0,
    borderStyle: "solid",
    borderColor: Color.colorSienna_100,
    borderTopWidth: 1,
    height: 86,
    justifyContent: "flex-end",
    overflow: "hidden",
    left: "50%",
    position: "absolute",
    alignItems: "center",
  },
  mapsIcon: {
    top: 383,
    left: 90,
  },
  mapsIcon1: {
    left: 213,
    top: 121,
  },
  geofencing: {
    flex: 1,
    height: 812,
    width: "100%",
    backgroundColor: Color.labelPrimary,
  },
});

export default Geofencing;
