import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { FontFamily, FontSize, Color, Border, Padding } from "../GlobalStyles";

const FarmDetails = () => {
  return (
    <View style={styles.farmDetails}>
      <View style={styles.background} />
      <Image
        style={styles.objectsIcon}
        contentFit="cover"
        source={require("../assets/objects1.png")}
      />
      <View style={styles.content}>
        <View style={styles.heading}>
          <Text style={[styles.profileSetUp, styles.nameOfFarmFlexBox]}>
            Profile Set-up
          </Text>
          <Text style={[styles.addMoreDetails, styles.farmTypo]}>
            Add more details about your Livestock.
          </Text>
          <Image
            style={[styles.vectorIcon, styles.vectorIconLayout]}
            contentFit="cover"
            source={require("../assets/vector.png")}
          />
        </View>
        <View style={styles.fields}>
          <View style={styles.next}>
            <Text style={[styles.next1, styles.next1FlexBox]}>Next</Text>
            <Image
              style={[styles.vectorIcon1, styles.vectorIconLayout]}
              contentFit="cover"
              source={require("../assets/vector1.png")}
            />
          </View>
          <View style={styles.name}>
            <Text style={[styles.nameOfFarm, styles.farmTypo]}>
              {" "}
              Name of Farm
            </Text>
          </View>
          <View style={[styles.dob, styles.dobFlexBox]}>
            <Text style={styles.farmTypo}>Namlist ID</Text>
            <Image
              style={styles.vectorIcon2}
              contentFit="cover"
              source={require("../assets/vector2.png")}
            />
          </View>
          <View style={[styles.sex, styles.sexLayout]}>
            <Text style={styles.farmTypo}>Number of LiveStock</Text>
          </View>
          <View style={[styles.height, styles.sexLayout]}>
            <Text style={styles.farmTypo}>Height</Text>
            <Text style={[styles.sizeOfFarm, styles.farmTypo]}>
              Size of Farm
            </Text>
          </View>
          <View style={[styles.weight, styles.weightLayout]}>
            <Text style={[styles.weight1, styles.farmTypo]}>Weight</Text>
          </View>
          <View style={[styles.bloodtype, styles.weightLayout]}>
            <Text style={[styles.typeOfLivestock, styles.farmTypo]}>
              Type of Livestock
            </Text>
          </View>
        </View>
      </View>
      <Image
        style={[styles.subject1Icon, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/subject-11.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  nameOfFarmFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
  },
  farmTypo: {
    fontFamily: FontFamily.robotoRegular,
    fontSize: FontSize.size_xs,
    textAlign: "center",
    color: Color.colorBlack,
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  next1FlexBox: {
    textAlign: "center",
    position: "absolute",
  },
  dobFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  sexLayout: {
    width: 130,
    left: 0,
    height: 35,
    borderRadius: Border.br_7xs,
    position: "absolute",
    backgroundColor: Color.labelPrimary,
  },
  weightLayout: {
    left: 156,
    width: 130,
    height: 35,
    borderRadius: Border.br_7xs,
    position: "absolute",
    backgroundColor: Color.labelPrimary,
  },
  background: {
    top: -26,
    left: -28,
    width: 428,
    height: 926,
    position: "absolute",
  },
  objectsIcon: {
    top: -382,
    left: -392,
    width: 1113,
    height: 1431,
    position: "absolute",
  },
  profileSetUp: {
    top: 0,
    left: 88,
    fontSize: FontSize.size_5xl,
    letterSpacing: 1.2,
    lineHeight: 32,
    fontWeight: "700",
    fontFamily: FontFamily.robotoBold,
    width: 166,
    height: 38,
    textAlign: "center",
    position: "absolute",
    color: Color.colorBlack,
    alignItems: "center",
    display: "flex",
  },
  addMoreDetails: {
    top: 69,
    left: 83,
    letterSpacing: 1,
    position: "absolute",
  },
  vectorIcon: {
    height: "16.87%",
    width: "6.72%",
    top: "14.46%",
    right: "93.28%",
    bottom: "68.67%",
    left: "0%",
  },
  heading: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 268,
    height: 83,
  },
  next1: {
    top: 6,
    left: 226,
    fontSize: FontSize.size_sm,
    letterSpacing: 0.1,
    lineHeight: 19,
    fontWeight: "500",
    fontFamily: FontFamily.robotoMedium,
    color: "#ededed",
  },
  vectorIcon1: {
    height: "25.81%",
    width: "22.54%",
    top: "38.71%",
    right: "14.08%",
    bottom: "35.48%",
    left: "63.38%",
  },
  next: {
    top: 223,
    left: 215,
    backgroundColor: Color.colorBlack,
    width: 71,
    height: 31,
    borderRadius: Border.br_7xs,
    position: "absolute",
  },
  nameOfFarm: {
    width: 84,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
  },
  name: {
    right: 0,
    bottom: 219,
    paddingVertical: Padding.p_4xs,
    paddingHorizontal: Padding.p_6xs,
    height: 35,
    borderRadius: Border.br_7xs,
    width: 286,
    position: "absolute",
    backgroundColor: Color.labelPrimary,
  },
  vectorIcon2: {
    width: 20,
    height: 22,
    marginLeft: 191,
  },
  dob: {
    top: 57,
    paddingHorizontal: Padding.p_4xs,
    paddingVertical: Padding.p_6xs,
    left: 0,
    flexDirection: "row",
    height: 35,
    borderRadius: Border.br_7xs,
    width: 286,
    position: "absolute",
    backgroundColor: Color.labelPrimary,
  },
  sex: {
    justifyContent: "flex-end",
    paddingVertical: Padding.p_5xs,
    top: 113,
    paddingHorizontal: Padding.p_6xs,
  },
  sizeOfFarm: {
    marginLeft: -36,
  },
  height: {
    paddingLeft: 17,
    paddingRight: 77,
    top: 168,
    flexDirection: "row",
    alignItems: "center",
  },
  weight1: {
    top: 11,
    left: 166,
    position: "absolute",
  },
  weight: {
    top: 168,
  },
  typeOfLivestock: {
    top: 10,
    left: 169,
    position: "absolute",
  },
  bloodtype: {
    top: 113,
  },
  fields: {
    height: 254,
    marginTop: 50,
    width: 286,
  },
  content: {
    top: 244,
    right: 16,
    borderRadius: Border.br_5xl,
    backgroundColor: "rgba(109, 66, 42, 0.21)",
    width: 346,
    height: 433,
    paddingHorizontal: 28,
    paddingVertical: Padding.p_xl,
    position: "absolute",
  },
  subject1Icon: {
    height: "19.09%",
    width: "48.8%",
    top: "8%",
    right: "27.2%",
    bottom: "72.91%",
    left: "24%",
  },
  farmDetails: {
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    backgroundColor: Color.labelPrimary,
  },
});

export default FarmDetails;
