import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, Border, FontSize, Padding } from "../GlobalStyles";

const Camera1 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.camera2}>
      <View style={[styles.camera2Inner, styles.text1FlexBox]}>
        <View style={styles.wrapper}>
          <Text style={[styles.text, styles.textTypo]}>0:00:02</Text>
        </View>
      </View>
      <View style={[styles.camera2Child, styles.containerBorder]} />
      <Image
        style={styles.screenshot20240425At0943}
        contentFit="cover"
        source={require("../assets/screenshot-20240425-at-0943-1.png")}
      />
      <View style={[styles.cameraActionButton, styles.cameraLayout]}>
        <Image
          style={styles.cameraActionButtonChild}
          contentFit="cover"
          source={require("../assets/ellipse-712.png")}
        />
      </View>
      <View style={[styles.cameraActionButton1, styles.homeIndicatorLayout]}>
        <Text style={[styles.sfSymbol, styles.textFlexBox]}>􀎡</Text>
      </View>
      <View style={[styles.timeline, styles.timelinePosition]}>
        <View style={[styles.timeline1, styles.text1FlexBox]}>
          <View style={styles.timelineScale}>
            <View style={[styles.hour, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
          </View>
          <View style={styles.hourParent}>
            <View style={[styles.hour, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
          </View>
          <View style={styles.hourParent}>
            <View style={[styles.hour, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
          </View>
          <View style={styles.hourParent}>
            <View style={[styles.hour, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
          </View>
          <View style={styles.hourParent}>
            <View style={[styles.hour, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
          </View>
          <View style={styles.hourParent}>
            <View style={[styles.hour, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
          </View>
          <View style={styles.hourParent}>
            <View style={[styles.hour, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
          </View>
          <View style={styles.hourParent}>
            <View style={[styles.hour, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
            <View style={[styles.quarter, styles.hourLayout]} />
          </View>
        </View>
        <Text style={[styles.timeStamp, styles.stampTypo]}>12:52:03 PM</Text>
        <Text style={[styles.nounStamp, styles.stampTypo]}>noun</Text>
        <View style={[styles.multicamArchive, styles.archivePosition1]}>
          <View style={[styles.archive, styles.archivePosition1]}>
            <View style={[styles.archiveBackground, styles.archivePosition]} />
            <View style={[styles.archiveActive, styles.archivePosition]} />
          </View>
        </View>
        <View style={[styles.nowStamp, styles.hourLayout]} />
      </View>
      <View style={[styles.navigationBar, styles.archivePosition]}>
        <View style={[styles.cameraSettingsParent, styles.containerFlexBox]}>
          <View style={[styles.cameraSettings, styles.text1Layout]}>
            <Text style={[styles.text1, styles.textLayout]}>􀍟</Text>
          </View>
          <View style={[styles.cameraStatusTags, styles.cameraFlexBox]}>
            <View style={styles.moon}>
              <Text style={[styles.icon, styles.iconTypo]}>􀍟</Text>
            </View>
            <Text style={[styles.label, styles.iconTypo]}>UPDATE</Text>
          </View>
        </View>
        <View style={[styles.label1, styles.label1FlexBox]}>
          <Text style={[styles.title, styles.titleTypo]}>Front Door</Text>
          <Text style={[styles.subtitle, styles.titleTypo]}>Subtitle</Text>
        </View>
        <Pressable
          style={styles.parent}
          onPress={() => navigation.navigate("Camera")}
        >
          <Text style={[styles.text2, styles.textLayout]}>􀆉</Text>
          <View style={[styles.cameraStatusTags1, styles.cameraSpaceBlock]}>
            <Text style={[styles.label2, styles.iconTypo]}>LIVE</Text>
          </View>
          <View style={[styles.cameraStatusTags2, styles.cameraSpaceBlock]}>
            <View style={styles.moon}>
              <Text style={[styles.icon1, styles.iconTypo]}>􀙇</Text>
            </View>
          </View>
          <View style={[styles.cameraStatusTags1, styles.cameraSpaceBlock]}>
            <Text style={[styles.label2, styles.iconTypo]}>RECORD</Text>
          </View>
          <View style={[styles.cameraStatusTags4, styles.cameraSpaceBlock]}>
            <Text style={[styles.label2, styles.iconTypo]}>LIVE</Text>
          </View>
        </Pressable>
      </View>
      <Image
        style={styles.screenshot20240425At0948}
        contentFit="cover"
        source={require("../assets/screenshot-20240425-at-0948-1.png")}
      />
      <Pressable
        style={[styles.cameraModeButton, styles.cameraFlexBox]}
        onPress={() => navigation.navigate("Emergency")}
      >
        <Text style={[styles.text3, styles.textTypo]}>􀙨</Text>
      </Pressable>
      <View style={[styles.container, styles.containerLayout]}>
        <View style={[styles.container1, styles.text1FlexBox]}>
          <Pressable
            style={styles.home}
            onPress={() => navigation.navigate("Homescreen1")}
          >
            <Image
              style={styles.homeIcon}
              contentFit="cover"
              source={require("../assets/home.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Home</Text>
          </Pressable>
          <Pressable
            style={[styles.saved, styles.savedSpaceBlock]}
            onPress={() => navigation.navigate("Geofencing")}
          >
            <Image
              style={styles.googleMapsIcon}
              contentFit="cover"
              source={require("../assets/google-maps.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Tracking</Text>
          </Pressable>
          <View style={[styles.saved1, styles.savedSpaceBlock]}>
            <Image
              style={[styles.cameraSettings, styles.text1Layout]}
              contentFit="cover"
              source={require("../assets/heart.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Saved</Text>
          </View>
          <View style={styles.savedSpaceBlock}>
            <Image
              style={styles.cameraIcon}
              contentFit="cover"
              source={require("../assets/camera.png")}
            />
            <Text style={[styles.home1, styles.home1Typo]}>Surveillance</Text>
          </View>
          <Pressable
            style={styles.savedSpaceBlock}
            onPress={() => navigation.navigate("Settings")}
          >
            <Image
              style={[styles.cameraSettings, styles.text1Layout]}
              contentFit="cover"
              source={require("../assets/user.png")}
            />
            <Text style={[styles.account, styles.home1Typo]}>Account</Text>
          </Pressable>
        </View>
        <View style={[styles.homeindicator, styles.containerLayout]}>
          <View style={[styles.homeIndicator, styles.homeIndicatorLayout]} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  text1FlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  textTypo: {
    textAlign: "center",
    color: Color.labelPrimary,
    fontFamily: FontFamily.caption2,
  },
  containerBorder: {
    borderTopWidth: 1,
    borderStyle: "solid",
  },
  cameraLayout: {
    height: 48,
    width: 48,
  },
  homeIndicatorLayout: {
    borderRadius: Border.br_81xl,
    position: "absolute",
  },
  textFlexBox: {
    letterSpacing: 0,
    textAlign: "center",
  },
  timelinePosition: {
    left: -1,
    width: 375,
  },
  hourLayout: {
    width: 1,
    borderRightWidth: 1,
    borderStyle: "solid",
  },
  stampTypo: {
    lineHeight: 18,
    fontSize: FontSize.caption2_size,
    left: "50%",
    letterSpacing: 0,
    textAlign: "center",
    fontFamily: FontFamily.caption2,
    position: "absolute",
  },
  archivePosition1: {
    left: 0,
    width: 375,
    position: "absolute",
  },
  archivePosition: {
    top: 0,
    position: "absolute",
  },
  containerFlexBox: {
    justifyContent: "flex-end",
    alignItems: "center",
    position: "absolute",
  },
  text1Layout: {
    width: 24,
    height: 24,
  },
  textLayout: {
    lineHeight: 22,
    color: Color.labelPrimary,
  },
  cameraFlexBox: {
    backgroundColor: Color.fillPrimary,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  iconTypo: {
    textAlign: "left",
    fontFamily: FontFamily.calloutBold,
    fontWeight: "600",
    lineHeight: 18,
    fontSize: FontSize.caption2_size,
    letterSpacing: 0,
  },
  label1FlexBox: {
    height: 22,
    justifyContent: "center",
    alignItems: "center",
  },
  titleTypo: {
    fontFamily: FontFamily.calloutBold,
    fontWeight: "600",
    display: "none",
    letterSpacing: 0,
    textAlign: "center",
  },
  cameraSpaceBlock: {
    marginLeft: 4,
    backgroundColor: Color.fillPrimary,
    paddingVertical: Padding.p_11xs,
    paddingHorizontal: Padding.p_5xs,
    flexDirection: "row",
  },
  containerLayout: {
    width: 390,
    backgroundColor: Color.labelPrimary,
  },
  home1Typo: {
    lineHeight: 17,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    fontFamily: FontFamily.caption2,
  },
  savedSpaceBlock: {
    marginLeft: 40,
    alignItems: "center",
  },
  text: {
    fontSize: FontSize.size_mini,
    lineHeight: 20,
  },
  wrapper: {
    borderRadius: Border.br_9xs,
    backgroundColor: "#ff453a",
    paddingVertical: Padding.p_11xs,
    paddingHorizontal: Padding.p_5xs,
    flexDirection: "row",
  },
  camera2Inner: {
    top: 14,
    height: 185,
    padding: Padding.p_xl,
    flexDirection: "row",
    width: 375,
    left: -1,
    position: "absolute",
  },
  camera2Child: {
    top: 678,
    left: 211,
    width: 119,
    height: 1,
    borderColor: Color.colorDimgray_200,
    borderTopWidth: 1,
    borderStyle: "solid",
    position: "absolute",
  },
  screenshot20240425At0943: {
    top: 370,
    left: 3,
    width: 371,
    height: 160,
    position: "absolute",
  },
  cameraActionButtonChild: {
    width: 40,
    height: 40,
  },
  cameraActionButton: {
    left: 306,
    borderRadius: Border.br_101xl,
    padding: Padding.p_9xs,
    backgroundColor: Color.labelPrimary,
    width: 48,
    top: 654,
    flexDirection: "row",
    position: "absolute",
  },
  sfSymbol: {
    fontSize: FontSize.size_lg,
    lineHeight: 18,
    opacity: 0.9,
    color: Color.labelPrimary,
    fontFamily: FontFamily.caption2,
    letterSpacing: 0,
  },
  cameraActionButton1: {
    left: 163,
    borderWidth: 1,
    paddingHorizontal: Padding.p_9xs,
    paddingTop: Padding.p_12xs,
    paddingBottom: Padding.p_9xs,
    height: 48,
    width: 48,
    top: 654,
    borderRadius: Border.br_81xl,
    borderColor: Color.colorDimgray_200,
    borderStyle: "solid",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  hour: {
    borderColor: Color.colorDarkslategray_300,
    height: 25,
  },
  quarter: {
    borderColor: Color.colorDarkslategray_400,
    height: 9,
    marginLeft: 16,
  },
  timelineScale: {
    borderRadius: Border.br_11xs,
    alignItems: "center",
    flexDirection: "row",
  },
  hourParent: {
    marginLeft: 16,
    borderRadius: Border.br_11xs,
    alignItems: "center",
    flexDirection: "row",
  },
  timeline1: {
    marginLeft: -187.5,
    left: "50%",
    top: 60,
    flexDirection: "row",
    width: 375,
    position: "absolute",
  },
  timeStamp: {
    marginLeft: -32.5,
    top: 27,
    color: Color.labelSecondary,
  },
  nounStamp: {
    marginLeft: -68.5,
    bottom: 2,
    color: Color.colorGray_100,
  },
  archiveBackground: {
    left: 123,
    backgroundColor: Color.colorDarkslategray_500,
    width: 63,
    height: 4,
    borderRadius: Border.br_11xs,
  },
  archiveActive: {
    left: 171,
    borderTopLeftRadius: Border.br_11xs,
    borderBottomLeftRadius: Border.br_11xs,
    backgroundColor: Color.accentColor,
    width: 16,
    height: 4,
  },
  archive: {
    top: 10,
    height: 4,
  },
  multicamArchive: {
    height: 24,
    top: 60,
  },
  nowStamp: {
    marginLeft: -1,
    bottom: 16,
    borderColor: Color.labelPrimary,
    height: 41,
    left: "50%",
    position: "absolute",
  },
  timeline: {
    top: 508,
    height: 108,
    overflow: "hidden",
    width: 375,
    position: "absolute",
  },
  text1: {
    marginTop: -12,
    marginLeft: -12,
    display: "flex",
    fontSize: FontSize.bodyBold_size,
    lineHeight: 22,
    top: "50%",
    left: "50%",
    position: "absolute",
    width: 24,
    height: 24,
    letterSpacing: 0,
    textAlign: "center",
    fontFamily: FontFamily.caption2,
    justifyContent: "center",
    alignItems: "center",
  },
  cameraSettings: {
    overflow: "hidden",
  },
  icon: {
    marginLeft: -6,
    color: Color.accentYellow,
    textAlign: "left",
    marginTop: -9,
    top: "50%",
    left: "50%",
    position: "absolute",
  },
  moon: {
    height: 16,
    width: 16,
    overflow: "hidden",
  },
  label: {
    marginLeft: 3,
    color: Color.accentYellow,
    textAlign: "left",
  },
  cameraStatusTags: {
    paddingLeft: Padding.p_7xs,
    paddingTop: Padding.p_11xs,
    paddingRight: Padding.p_5xs,
    paddingBottom: Padding.p_11xs,
    display: "none",
    borderRadius: Border.br_xs,
    marginLeft: 16,
  },
  cameraSettingsParent: {
    top: 57,
    right: 15,
    height: 24,
    flexDirection: "row",
  },
  title: {
    lineHeight: 22,
    color: Color.labelPrimary,
    fontSize: FontSize.bodyBold_size,
  },
  subtitle: {
    fontSize: FontSize.size_smi,
    lineHeight: 15,
    color: Color.accentGreen,
  },
  label1: {
    marginTop: 12,
    marginLeft: -18.5,
    width: 36,
    top: "50%",
    left: "50%",
    position: "absolute",
  },
  text2: {
    fontSize: FontSize.size_3xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    letterSpacing: 0,
    textAlign: "center",
  },
  label2: {
    color: Color.labelPrimary,
  },
  cameraStatusTags1: {
    borderRadius: Border.br_xs,
  },
  icon1: {
    marginLeft: -7.5,
    marginTop: -9,
    top: "50%",
    left: "50%",
    position: "absolute",
    color: Color.labelPrimary,
  },
  cameraStatusTags2: {
    borderRadius: Border.br_2xs,
    height: 22,
    justifyContent: "center",
    alignItems: "center",
  },
  cameraStatusTags4: {
    display: "none",
    borderRadius: Border.br_xs,
  },
  parent: {
    bottom: 12,
    left: 6,
    alignItems: "center",
    flexDirection: "row",
    position: "absolute",
  },
  navigationBar: {
    height: 91,
    width: 375,
    left: -1,
  },
  screenshot20240425At0948: {
    top: 146,
    left: -2,
    height: 186,
    width: 375,
    position: "absolute",
  },
  text3: {
    fontSize: FontSize.size_5xl,
    lineHeight: 24,
  },
  cameraModeButton: {
    top: 658,
    left: 11,
    borderRadius: Border.br_5xl,
    height: 48,
    width: 48,
    position: "absolute",
  },
  homeIcon: {
    width: 29,
    height: 32,
    overflow: "hidden",
  },
  home1: {
    color: Color.primary400,
  },
  home: {
    alignItems: "center",
  },
  googleMapsIcon: {
    height: 36,
    width: 36,
  },
  saved: {
    width: 26,
    height: 59,
  },
  saved1: {
    display: "none",
  },
  cameraIcon: {
    width: 38,
    height: 30,
  },
  account: {
    color: Color.colorDarkgray_100,
  },
  container1: {
    height: 57,
    flexDirection: "row",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    backgroundColor: Color.primary900,
    width: 134,
    height: 5,
    display: "none",
    left: "50%",
  },
  homeindicator: {
    height: 27,
    marginTop: -4,
  },
  container: {
    marginLeft: -195.5,
    bottom: 0,
    borderColor: Color.colorSienna_100,
    height: 86,
    justifyContent: "flex-end",
    alignItems: "center",
    position: "absolute",
    left: "50%",
    overflow: "hidden",
    borderTopWidth: 1,
    borderStyle: "solid",
    width: 390,
  },
  camera2: {
    backgroundColor: Color.colorBlack,
    flex: 1,
    width: "100%",
    height: 812,
  },
});

export default Camera1;
